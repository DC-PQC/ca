"""
main.py - Flask application entry point.

Local development  : python main.py
Production (GCP VM): gunicorn -w 2 -b 0.0.0.0:5000 --timeout 120 main:app
"""
import logging
import os
import sys

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask

from config import Config, validate_config
from inventory import build_inventory, get_inventory
from scheduler import init_scheduler
import gcp_crypto_monitor as crypto_monitor

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    validate_config()

    app = Flask(__name__)
    app.config.from_object(Config)

    # Auth - only if REQUIRE_AUTH=true
    if Config.REQUIRE_AUTH:
        from auth import init_auth, auth_bp
        init_auth(app)
        app.register_blueprint(auth_bp, url_prefix="/auth")
        logger.info("Entra authentication ENABLED")
    else:
        logger.warning("REQUIRE_AUTH=false - authentication DISABLED")

    # Build initial inventory
    logger.info("Running initial inventory build...")
    build_inventory()

    # Initial crypto asset collection
    logger.info("Running initial GCP crypto asset collection...")
    projects = get_inventory().get("projects", [])
    if projects:
        crypto_monitor.refresh_all(projects)
    else:
        logger.warning("No projects found - check GCP_PROJECT_IDS in .env")

    # Start daily scheduler
    init_scheduler()

    # Register blueprints
    from blueprints.dashboard import dashboard_bp
    from blueprints.health import health_bp
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(health_bp)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

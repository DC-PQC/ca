#!/bin/bash
# ============================================================
# setup_service_account.sh
# Run this from your LOCAL machine or Cloud Shell ONCE
# to create the service account and grant roles on all 8 projects
#
# Usage:
#   1. Edit the variables below with your real values
#   2. bash setup_service_account.sh
# ============================================================

# ── EDIT THESE VALUES ─────────────────────────────────────────
SA_PROJECT="prefab-bounty-480110-d2"       # Project where SA lives
SA_NAME="cscrf-monitor"                    # Service account name

# Your 8 project IDs to scan
PROJECTS=(
    "project-id-1"
    "project-id-2"
    "project-id-3"
    "project-id-4"
    "project-id-5"
    "project-id-6"
    "project-id-7"
    "project-id-8"
)

# VM details (to attach service account)
VM_NAME="your-vm-name"
VM_ZONE="asia-south1-a"
# ──────────────────────────────────────────────────────────────

SA_EMAIL="$SA_NAME@$SA_PROJECT.iam.gserviceaccount.com"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo "================================================"
echo "  CSCRF - Service Account Setup"
echo "================================================"
echo ""

# Step 1: Create service account
echo -e "${GREEN}[1/3] Creating service account...${NC}"
gcloud iam service-accounts create $SA_NAME \
    --display-name="CSCRF Dashboard Monitor" \
    --description="Monitors GCP resources for CSCRF dashboard" \
    --project=$SA_PROJECT 2>/dev/null || echo "  Service account already exists"

echo "  SA Email: $SA_EMAIL"
echo ""

# Step 2: Grant roles on each project
echo -e "${GREEN}[2/3] Granting IAM roles on all projects...${NC}"
echo ""

# Minimum required roles - read-only access only
ROLES=(
    "roles/privateca.auditor"          # Read CAS certificates
    "roles/cloudkms.viewer"            # Read KMS keyrings and keys
    "roles/secretmanager.viewer"       # Read Secret Manager secrets
    "roles/securitycenter.findingsViewer"  # Read SCC vulnerabilities
    "roles/viewer"                     # Read project resources
)

for PROJECT in "${PROJECTS[@]}"; do
    echo "  Project: $PROJECT"
    for ROLE in "${ROLES[@]}"; do
        gcloud projects add-iam-policy-binding "$PROJECT" \
            --member="serviceAccount:$SA_EMAIL" \
            --role="$ROLE" \
            --quiet 2>/dev/null && echo "    + $ROLE" || echo "    ! Failed: $ROLE"
    done
    echo ""
done

# Step 3: Attach service account to VM
echo -e "${GREEN}[3/3] Attaching service account to VM...${NC}"
gcloud compute instances set-service-account $VM_NAME \
    --zone=$VM_ZONE \
    --service-account=$SA_EMAIL \
    --scopes=https://www.googleapis.com/auth/cloud-platform

echo ""
echo "================================================"
echo -e "  ${GREEN}Setup Complete!${NC}"
echo "================================================"
echo ""
echo "  Service Account : $SA_EMAIL"
echo "  Attached to VM  : $VM_NAME ($VM_ZONE)"
echo ""
echo -e "  ${YELLOW}Next step: SSH into VM and run deploy.sh${NC}"
echo ""

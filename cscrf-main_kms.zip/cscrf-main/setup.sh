#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  CSCRF Dashboard — One-shot setup script for Debian 12 GCE VM
#  Run as: bash setup.sh
# ─────────────────────────────────────────────────────────────
set -e

echo "=========================================="
echo "  CSCRF Dashboard Setup"
echo "=========================================="

# ── 1. System packages ──────────────────────────────────────
echo "[1/6] Installing system packages..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
    python3 python3-pip python3-venv \
    git curl unzip wget

# ── 2. App directory ────────────────────────────────────────
echo "[2/6] Setting up app directory..."
mkdir -p ~/cscrf-dashboard
cd ~/cscrf-dashboard

# ── 3. Upload detection — wait for app files ────────────────
echo "[3/6] Checking for app files..."
if [ ! -f "main.py" ]; then
    echo ""
    echo "  ⚠️  App files not found in ~/cscrf-dashboard"
    echo "  Please upload cscrf-main.zip and run:"
    echo "    unzip cscrf-main.zip -d ~/cscrf-dashboard"
    echo "    cp -r ~/cscrf-dashboard/cscrf-main/* ~/cscrf-dashboard/"
    echo "  Then re-run this script."
    echo ""
    exit 1
fi

# ── 4. Python virtual environment ───────────────────────────
echo "[4/6] Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
    pip install google-cloud-kms google-cloud-secret-manager -q
echo "  ✅ Dependencies installed"

# ── 5. .env file ────────────────────────────────────────────
echo "[5/6] Configuring environment..."
if [ ! -f ".env" ]; then
    cat > .env << 'ENVEOF'
FLASK_SECRET_KEY=a825e32116e6fcad6555c958f65e8c81999c182fa93a20f9c18f947cf4c5aafe
DASHBOARD_USERNAME=admin
DASHBOARD_PASSWORD=CscrfDemo@2026
GCP_PROJECT_IDS=prefab-bounty-480110-d2,secure-masking-demo,academic-matter-479914-u9
HRMS_API_URL=http://placeholder.local
ENVEOF
    echo "  ✅ .env created"
else
    echo "  ✅ .env already exists — skipping"
fi

# ── 6. Systemd service ──────────────────────────────────────
echo "[6/6] Installing systemd service..."
APPDIR="$HOME/cscrf-dashboard"
USERNAME=$(whoami)

sudo tee /etc/systemd/system/cscrf-dashboard.service > /dev/null << SVCEOF
[Unit]
Description=CSCRF Security Dashboard
After=network.target

[Service]
Type=simple
User=${USERNAME}
WorkingDirectory=${APPDIR}
EnvironmentFile=${APPDIR}/.env
ExecStart=${APPDIR}/venv/bin/gunicorn -w 2 -b 0.0.0.0:5000 --timeout 120 --access-logfile - --error-logfile - main:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF

sudo systemctl daemon-reload
sudo systemctl enable cscrf-dashboard
sudo systemctl restart cscrf-dashboard

echo ""
echo "=========================================="
echo "  ✅ CSCRF Dashboard is RUNNING"
echo "=========================================="
echo ""
echo "  URL     : http://$(curl -s ifconfig.me):5000"
echo "  Username: admin"
echo "  Password: CscrfDemo@2026"
echo ""
echo "  Useful commands:"
echo "    sudo systemctl status cscrf-dashboard   # check status"
echo "    sudo journalctl -u cscrf-dashboard -f   # live logs"
echo "    sudo systemctl restart cscrf-dashboard  # restart"
echo ""

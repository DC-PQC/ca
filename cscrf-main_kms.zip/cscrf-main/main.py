from inventory import build_inventory
from config import Config, validate_config
from flask import Flask
from auth import init_auth, auth_bp
from blueprints.dashboard import dashboard_bp
from blueprints.health import health_bp
from scheduler import init_scheduler
import threading


def create_app():
    # 1. Validate config
    validate_config()

    # 2. Flask init
    app = Flask(__name__)
    app.config.from_object(Config)

    # 3. Auth (simple username/password — no Entra)
    init_auth(app)
    app.register_blueprint(auth_bp, url_prefix="/auth")

    # 4. Build GCP project inventory at startup
    build_inventory()

    # 5. Kick off initial GCP asset collection in background threads
    #    so KMS / Certificates / Secrets are populated immediately
    from scheduler import (
        _collect_kms_metrics_job,
        _collect_certificate_metrics_job,
        _collect_secret_metrics_job,
        _collect_vulnerability_metrics_job,
    )
    for job_fn in [
        _collect_vulnerability_metrics_job,
        _collect_kms_metrics_job,
        _collect_certificate_metrics_job,
        _collect_secret_metrics_job,
    ]:
        t = threading.Thread(target=job_fn, daemon=True)
        t.start()

    # 6. Start background scheduler
    init_scheduler()

    # 7. Register routes
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(health_bp)

    return app


app = create_app()


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False
    )

"""
Centralized scheduler configuration for background tasks.

All periodic jobs (inventory refresh, aggregation, etc.) are defined here.
"""
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from config import Config
from inventory import build_inventory, get_inventory
from metrics import (
    collect_vulnerability_metrics_from_projects, 
    update_vulnerability_metrics,
    collect_security_training_metrics,
    update_security_training_metrics,
    collect_mfa_metrics,
    update_mfa_metrics,
    collect_critical_assets_siem_metrics,
    update_critical_assets_siem_metrics
)
from gcp_assets import (
    collect_kms_metrics, update_kms_metrics,
    collect_certificate_metrics, update_certificate_metrics,
    collect_secret_metrics, update_secret_metrics,
)

logger = logging.getLogger(__name__)

_scheduler = None


def init_scheduler():
    """Initialize and start the background scheduler."""
    global _scheduler
    
    if _scheduler is not None:
        logger.warning("Scheduler already initialized")
        return _scheduler
    
    _scheduler = BackgroundScheduler()
    
    # Register all scheduled jobs
    _register_jobs()
    
    _scheduler.start()
    logger.info("Background scheduler started")
    return _scheduler


def _register_jobs():
    """Register all background jobs."""
    
    # 1. Inventory refresh job
    _scheduler.add_job(
        func=build_inventory,
        trigger="interval",
        hours=Config.INVENTORY_REFRESH_HOURS,
        id="inventory_refresh",
        replace_existing=True,
        max_instances=1,  # Prevent concurrent runs
        name="Inventory Refresh"
    )
    logger.info(f"Registered job: inventory_refresh (every {Config.INVENTORY_REFRESH_HOURS} hours)")
    
    # 2. Vulnerability metrics collection job
    _scheduler.add_job(
        func=_collect_vulnerability_metrics_job,
        trigger="interval",
        hours=1,
        id="vulnerability_collection",
        replace_existing=True,
        max_instances=1,
        name="Vulnerability Metrics Collection"
    )
    logger.info("Registered job: vulnerability_collection (every 1 hour)")
    
    # 3. Security training metrics collection job
    _scheduler.add_job(
        func=_collect_security_training_metrics_job,
        trigger="interval",
        hours=6,
        id="security_training_collection",
        replace_existing=True,
        max_instances=1,
        name="Security Training Metrics Collection"
    )
    logger.info("Registered job: security_training_collection (every 6 hours)")
    
    # 4. MFA / Remote Access Control metrics collection job
    _scheduler.add_job(
        func=_collect_mfa_metrics_job,
        trigger="interval",
        hours=2,
        id="mfa_collection",
        replace_existing=True,
        max_instances=1,
        name="MFA Remote Access Metrics Collection"
    )
    logger.info("Registered job: mfa_collection (every 2 hours)")
    
    # 5. Critical Assets SIEM Integration metrics collection job
    _scheduler.add_job(
        func=_collect_critical_assets_siem_metrics_job,
        trigger="interval",
        hours=4,
        id="critical_assets_siem_collection",
        replace_existing=True,
        max_instances=1,
        name="Critical Assets SIEM Integration Collection"
    )
    logger.info("Registered job: critical_assets_siem_collection (every 4 hours)")

    # 6. Cloud KMS metrics collection job
    _scheduler.add_job(
        func=_collect_kms_metrics_job,
        trigger="interval",
        hours=2,
        id="kms_collection",
        replace_existing=True,
        max_instances=1,
        name="Cloud KMS Metrics Collection"
    )
    logger.info("Registered job: kms_collection (every 2 hours)")

    # 7. Certificate metrics collection job
    _scheduler.add_job(
        func=_collect_certificate_metrics_job,
        trigger="interval",
        hours=6,
        id="certificate_collection",
        replace_existing=True,
        max_instances=1,
        name="Certificate Metrics Collection"
    )
    logger.info("Registered job: certificate_collection (every 6 hours)")

    # 8. Secret Manager metrics collection job
    _scheduler.add_job(
        func=_collect_secret_metrics_job,
        trigger="interval",
        hours=4,
        id="secret_collection",
        replace_existing=True,
        max_instances=1,
        name="Secret Manager Metrics Collection"
    )
    logger.info("Registered job: secret_collection (every 4 hours)")
    
    # 6. Placeholder for aggregation job (uncomment when ready)
    # _scheduler.add_job(
    #     func=aggregate_metrics,
    #     trigger="interval",
    #     hours=1,
    #     id="aggregation_job",
    #     replace_existing=True,
    #     max_instances=1,
    #     name="Metrics Aggregation"
    # )
    # logger.info("Registered job: aggregation_job (every 1 hour)")
    
    # 4. Placeholder for compliance check job (uncomment when ready)
    # _scheduler.add_job(
    #     func=compliance_check,
    #     trigger="interval",
    #     hours=2,
    #     id="compliance_check",
    #     replace_existing=True,
    #     max_instances=1,
    #     name="Compliance Check"
    # )
    # logger.info("Registered job: compliance_check (every 2 hours)")


def _collect_vulnerability_metrics_job():
    """Job wrapper to collect vulnerability metrics."""
    try:
        inventory = get_inventory()
        projects = inventory.get("projects", [])
        
        if not projects:
            logger.warning("No projects available for vulnerability collection")
            return
        
        metrics = collect_vulnerability_metrics_from_projects(projects)
        update_vulnerability_metrics(metrics)
        
        logger.info(
            f"Vulnerability metrics job completed: "
            f"{metrics['vulnerabilities_identified']} identified, "
            f"{metrics['vulnerabilities_mitigated']} mitigated, "
            f"{metrics['remediation_percentage']:.2f}% remediation"
        )
    except Exception as e:
        logger.error(f"Error in vulnerability collection job: {e}", exc_info=True)


def _collect_security_training_metrics_job():
    """Job wrapper to collect security training metrics from HRMS."""
    try:
        metrics = collect_security_training_metrics(
            hrms_url=Config.HRMS_API_URL,
            hrms_key=Config.HRMS_API_KEY,
            hrms_username=Config.HRMS_API_USERNAME,
            hrms_password=Config.HRMS_API_PASSWORD
        )
        update_security_training_metrics(metrics)
        
        logger.info(
            f"Security training metrics job completed: "
            f"{metrics['personnel_trained']} / {metrics['total_personnel']} trained, "
            f"{metrics['training_percentage']:.2f}% completion"
        )
    except Exception as e:
        logger.error(f"Error in security training collection job: {e}", exc_info=True)


def _collect_mfa_metrics_job():
    """Job wrapper to collect MFA metrics for remote access control."""
    try:
        metrics = collect_mfa_metrics(
            rac_url=Config.RAC_API_URL,
            rac_key=Config.RAC_API_KEY,
            rac_username=Config.RAC_API_USERNAME,
            rac_password=Config.RAC_API_PASSWORD,
            audit_log_project=Config.RAC_AUDIT_LOG_PROJECT,
            include_iap=Config.RAC_INCLUDE_IDENTITY_AWARE_PROXY
        )
        update_mfa_metrics(metrics)
        
        logger.info(
            f"MFA metrics job completed: "
            f"{metrics['remote_users_with_mfa']} / {metrics['total_remote_users']} with MFA, "
            f"{metrics['mfa_percentage']:.2f}% MFA enforcement"
        )
    except Exception as e:
        logger.error(f"Error in MFA collection job: {e}", exc_info=True)


def _collect_critical_assets_siem_metrics_job():
    """Job wrapper to collect critical assets SIEM integration metrics."""
    try:
        inventory = get_inventory()
        projects = inventory.get("projects", [])
        
        if not projects:
            logger.warning("No projects available for critical assets SIEM collection")
            return
        
        metrics = collect_critical_assets_siem_metrics(
            projects=projects,
            siem_type=Config.SIEM_TYPE,
            siem_url=Config.SIEM_API_URL,
            siem_key=Config.SIEM_API_KEY,
            siem_username=Config.SIEM_API_USERNAME,
            siem_password=Config.SIEM_API_PASSWORD,
            critical_label_key=Config.CRITICAL_ASSET_LABEL_KEY,
            critical_label_value=Config.CRITICAL_ASSET_LABEL_VALUE
        )
        update_critical_assets_siem_metrics(metrics)
        
        logger.info(
            f"Critical assets SIEM metrics job completed: "
            f"{metrics['critical_assets_integrated']} / {metrics['total_critical_assets']} integrated, "
            f"{metrics['integration_percentage']:.2f}% SIEM integration"
        )
    except Exception as e:
        logger.error(f"Error in critical assets SIEM collection job: {e}", exc_info=True)


def _collect_kms_metrics_job():
    """Job wrapper to collect Cloud KMS metrics."""
    try:
        inventory = get_inventory()
        projects = inventory.get("projects", [])
        if not projects:
            logger.warning("No projects available for KMS collection")
            return
        metrics = collect_kms_metrics(projects)
        update_kms_metrics(metrics)
        logger.info(
            f"KMS metrics job completed: "
            f"{metrics['total_keyrings']} keyrings, {metrics['total_crypto_keys']} keys"
        )
    except Exception as e:
        logger.error(f"Error in KMS collection job: {e}", exc_info=True)


def _collect_certificate_metrics_job():
    """Job wrapper to collect Certificate Authority Service metrics."""
    try:
        inventory = get_inventory()
        projects = inventory.get("projects", [])
        if not projects:
            logger.warning("No projects available for certificate collection")
            return
        metrics = collect_certificate_metrics(projects)
        update_certificate_metrics(metrics)
        logger.info(
            f"Certificate metrics job completed: "
            f"{metrics['total']} total, {metrics['expiring_soon']} expiring soon"
        )
    except Exception as e:
        logger.error(f"Error in certificate collection job: {e}", exc_info=True)


def _collect_secret_metrics_job():
    """Job wrapper to collect Secret Manager metrics."""
    try:
        inventory = get_inventory()
        projects = inventory.get("projects", [])
        if not projects:
            logger.warning("No projects available for secret collection")
            return
        metrics = collect_secret_metrics(projects)
        update_secret_metrics(metrics)
        logger.info(
            f"Secret Manager metrics job completed: "
            f"{metrics['total']} total, {metrics['active']} active"
        )
    except Exception as e:
        logger.error(f"Error in secret collection job: {e}", exc_info=True)


def get_scheduler():
    """Get the global scheduler instance."""
    if _scheduler is None:
        raise RuntimeError("Scheduler not initialized. Call init_scheduler() first.")
    return _scheduler


def shutdown_scheduler():
    """Gracefully shut down the scheduler."""
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown()
        _scheduler = None
        logger.info("Background scheduler shut down")


__all__ = ["init_scheduler", "get_scheduler", "shutdown_scheduler"]

import threading
from datetime import datetime
from config import Config

_inventory_lock = threading.Lock()
_inventory_state = {
    "last_refreshed": None,
    "projects": []
}


def build_inventory():
    """
    Build the project list from either:
    1. GCP_PROJECT_IDS env var (comma-separated list) — used for local/demo
    2. GCP_ORG_ID env var — discovers all projects under the org (production)
    """
    if Config.GCP_PROJECT_IDS:
        # Direct project list — no org-level discovery needed
        projects = [
            {"project_id": pid, "folder": None}
            for pid in Config.GCP_PROJECT_IDS
            if pid not in Config.EXCLUDED_PROJECT_IDS
        ]
    elif Config.GCP_ORG_ID:
        # Org-wide discovery (replace with real resourcemanager API calls for production)
        discovered = []  # TODO: list via resourcemanager API
        projects = [
            p for p in discovered
            if p.get("folder") not in Config.EXCLUDED_FOLDERS
            and p.get("project_id") not in Config.EXCLUDED_PROJECT_IDS
        ]
    else:
        projects = []

    with _inventory_lock:
        _inventory_state["projects"] = projects
        _inventory_state["last_refreshed"] = datetime.utcnow()


def get_inventory():
    with _inventory_lock:
        return _inventory_state.copy()

from flask import Blueprint, render_template
from inventory import get_inventory
from metrics import (
    get_vulnerability_metrics,
    get_security_training_metrics,
    get_mfa_metrics,
    get_critical_assets_siem_metrics
)
from gcp_assets import get_kms_metrics, get_certificate_metrics, get_secret_metrics
from auth import login_required

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/")
@login_required
def dashboard():
    inventory = get_inventory()
    vulnerability_metrics = get_vulnerability_metrics()
    training_metrics = get_security_training_metrics()
    mfa_metrics = get_mfa_metrics()
    siem_metrics = get_critical_assets_siem_metrics()
    kms_metrics = get_kms_metrics()
    cert_metrics = get_certificate_metrics()
    secret_metrics = get_secret_metrics()
    
    return render_template(
        "dashboard.html",
        project_count=len(inventory["projects"]),
        last_refreshed=inventory["last_refreshed"],
        vulnerabilities_identified=vulnerability_metrics.get("vulnerabilities_identified", 0),
        vulnerabilities_mitigated=vulnerability_metrics.get("vulnerabilities_mitigated", 0),
        remediation_percentage=vulnerability_metrics.get("remediation_percentage", 0.0),
        metrics_last_collected=vulnerability_metrics.get("last_collected"),
        by_project=vulnerability_metrics.get("by_project", {}),
        training_total_personnel=training_metrics.get("total_personnel", 0),
        training_personnel_trained=training_metrics.get("personnel_trained", 0),
        training_percentage=training_metrics.get("training_percentage", 0.0),
        training_last_collected=training_metrics.get("last_collected"),
        mfa_total_remote_users=mfa_metrics.get("total_remote_users", 0),
        mfa_remote_users_with_mfa=mfa_metrics.get("remote_users_with_mfa", 0),
        mfa_percentage=mfa_metrics.get("mfa_percentage", 0.0),
        mfa_last_collected=mfa_metrics.get("last_collected"),
        mfa_by_application=mfa_metrics.get("by_application", {}),
        siem_total_critical_assets=siem_metrics.get("total_critical_assets", 0),
        siem_critical_assets_integrated=siem_metrics.get("critical_assets_integrated", 0),
        siem_integration_percentage=siem_metrics.get("integration_percentage", 0.0),
        siem_last_collected=siem_metrics.get("last_collected"),
        siem_by_type=siem_metrics.get("by_type", {}),
        siem_by_project=siem_metrics.get("by_project", {}),
        # KMS
        kms_total_keyrings=kms_metrics.get("total_keyrings", 0),
        kms_total_crypto_keys=kms_metrics.get("total_crypto_keys", 0),
        kms_total_enabled_versions=kms_metrics.get("total_enabled_versions", 0),
        kms_total_disabled_versions=kms_metrics.get("total_disabled_versions", 0),
        kms_total_destroyed_versions=kms_metrics.get("total_destroyed_versions", 0),
        kms_keys=kms_metrics.get("keys", []),
        kms_last_collected=kms_metrics.get("last_collected"),
        # Certificates
        cert_total=cert_metrics.get("total", 0),
        cert_active=cert_metrics.get("active", 0),
        cert_expiring_soon=cert_metrics.get("expiring_soon", 0),
        cert_expired=cert_metrics.get("expired", 0),
        cert_list=cert_metrics.get("certs", []),
        cert_last_collected=cert_metrics.get("last_collected"),
        # Secret Manager
        secret_total=secret_metrics.get("total", 0),
        secret_active=secret_metrics.get("active", 0),
        secret_disabled=secret_metrics.get("disabled", 0),
        secret_list=secret_metrics.get("secrets", []),
        secret_last_collected=secret_metrics.get("last_collected"),
    )

#!/bin/bash
# Run this ONCE from Cloud Shell to allow port 5000
gcloud compute firewall-rules create allow-cscrf-dashboard \
    --project=prefab-bounty-480110-d2 \
    --allow=tcp:5000 \
    --source-ranges=0.0.0.0/0 \
    --target-tags=cscrf-dashboard \
    --description="Allow CSCRF dashboard on port 5000"

gcloud compute instances add-tags kms-dashboard-vm \
    --tags=cscrf-dashboard \
    --zone=us-central1-a \
    --project=prefab-bounty-480110-d2

echo "✅ Firewall rule added. Dashboard accessible on port 5000."

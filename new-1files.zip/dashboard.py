# =============================================================
#  dashboard.py  —  Flask app + embedded UI (no templates dir)
#  Run:  python dashboard.py
#  Open: http://localhost:8080
# =============================================================

from flask import Flask, jsonify, Response
import metrics
import scheduler
import config

app = Flask(__name__)

# ── Start background scheduler on boot ───────────────────────
scheduler.start()

# ── Embedded HTML dashboard ───────────────────────────────────
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>GCP Secret Vault Monitor</title>
<link href="https://fonts.googleapis.com/css2?family=Syne+Mono&family=Epilogue:wght@300;400;500;600&display=swap" rel="stylesheet"/>
<style>
:root{
  --bg:#05080f;--surface:#0b1120;--surface2:#0f1929;--border:#162236;
  --accent:#00e5ff;--green:#00f593;--yellow:#ffcb47;--orange:#ff8c42;
  --red:#ff3d6b;--muted:#3d5a7a;--text:#b8d4f0;
  --mono:'Syne Mono',monospace;--sans:'Epilogue',sans-serif;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:var(--sans);min-height:100vh;overflow-x:hidden}

/* grid bg */
body::before{
  content:'';position:fixed;inset:0;
  background-image:
    linear-gradient(rgba(0,229,255,.025) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,229,255,.025) 1px,transparent 1px);
  background-size:48px 48px;pointer-events:none;z-index:0
}

/* ── HEADER ── */
header{
  position:relative;z-index:10;
  display:flex;align-items:center;justify-content:space-between;
  padding:16px 36px;
  border-bottom:1px solid var(--border);
  background:linear-gradient(90deg,#08111e,var(--bg))
}
.brand{display:flex;align-items:center;gap:14px}
.brand-icon{
  width:42px;height:42px;border-radius:10px;
  background:linear-gradient(135deg,#00e5ff18,#00e5ff33);
  border:1px solid #00e5ff55;
  display:flex;align-items:center;justify-content:center;font-size:20px;
  box-shadow:0 0 24px #00e5ff22
}
.brand-title{font-family:var(--mono);font-size:14px;letter-spacing:3px;color:var(--accent);text-transform:uppercase}
.brand-sub{font-size:11px;color:var(--muted);letter-spacing:1px;margin-top:3px}
.header-right{display:flex;align-items:center;gap:12px}
.scan-time{font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:1px}
#scan-time-val{color:var(--accent)}
.btn{font-family:var(--mono);font-size:11px;letter-spacing:1px;padding:8px 18px;border-radius:5px;border:none;cursor:pointer;transition:all .2s;text-transform:uppercase}
.btn-refresh{background:transparent;border:1px solid var(--accent);color:var(--accent)}
.btn-refresh:hover{background:var(--accent);color:var(--bg);box-shadow:0 0 20px #00e5ff44}
.btn-alert{background:linear-gradient(135deg,var(--red),#c9184a);color:#fff}
.btn-alert:hover{box-shadow:0 0 20px #ff3d6b44;transform:translateY(-1px)}

/* ── MAIN ── */
main{position:relative;z-index:5;max-width:1440px;margin:0 auto;padding:28px 36px}

/* ── STAT CARDS ── */
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:14px;margin-bottom:28px}
.card{
  background:var(--surface);border:1px solid var(--border);border-radius:10px;
  padding:18px 20px;position:relative;overflow:hidden;transition:transform .2s,box-shadow .2s
}
.card:hover{transform:translateY(-3px);box-shadow:0 10px 32px rgba(0,0,0,.4)}
.card::after{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.card.total::after{background:var(--accent)}
.card.expired::after{background:var(--red)}
.card.critical::after{background:var(--orange)}
.card.warning::after{background:var(--yellow)}
.card.ok::after{background:var(--green)}
.card.noexp::after{background:var(--muted)}
.card-label{font-family:var(--mono);font-size:9px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;margin-bottom:10px}
.card-val{font-family:var(--mono);font-size:38px;line-height:1;font-weight:bold}
.card.total .card-val{color:var(--accent)}
.card.expired .card-val{color:var(--red)}
.card.critical .card-val{color:var(--orange)}
.card.warning .card-val{color:var(--yellow)}
.card.ok .card-val{color:var(--green)}
.card.noexp .card-val{color:var(--muted)}
.card-sub{font-size:11px;color:var(--muted);margin-top:5px}

/* ── TWO COLUMN LAYOUT ── */
.cols{display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start}

/* ── SCHEDULER PANEL ── */
.panel{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden}
.panel-head{
  background:var(--surface2);border-bottom:1px solid var(--border);
  padding:14px 20px;display:flex;align-items:center;justify-content:space-between
}
.panel-title{font-family:var(--mono);font-size:10px;letter-spacing:2px;color:var(--muted);text-transform:uppercase}
.status-pill{
  font-family:var(--mono);font-size:10px;letter-spacing:1px;
  padding:3px 10px;border-radius:20px
}
.status-pill.running{background:#00f59322;color:var(--green);border:1px solid #00f59344;animation:pulse-pill 2s infinite}
.status-pill.stopped{background:#ff3d6b22;color:var(--red);border:1px solid #ff3d6b44}
@keyframes pulse-pill{0%,100%{opacity:1}50%{opacity:.5}}
.panel-body{padding:20px}
.sched-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
.sched-label{font-family:var(--mono);font-size:10px;letter-spacing:1px;color:var(--muted);text-transform:uppercase}
.sched-val{font-family:var(--mono);font-size:12px;color:var(--text)}
.sched-val.accent{color:var(--accent)}
.sched-val.green{color:var(--green)}

/* countdown ring */
.countdown-wrap{display:flex;justify-content:center;margin:16px 0}
.countdown-ring{position:relative;width:100px;height:100px}
.countdown-ring svg{transform:rotate(-90deg)}
.ring-bg{stroke:var(--border);fill:none;stroke-width:6}
.ring-fill{fill:none;stroke-width:6;stroke-linecap:round;transition:stroke-dashoffset .9s linear}
.ring-text{
  position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center;text-align:center
}
.ring-num{font-family:var(--mono);font-size:20px;color:var(--accent)}
.ring-unit{font-family:var(--mono);font-size:9px;color:var(--muted);letter-spacing:1px}

/* scheduler log */
.log-title{font-family:var(--mono);font-size:9px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;margin-bottom:8px}
.log-box{background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:10px;max-height:160px;overflow-y:auto}
.log-entry{font-family:var(--mono);font-size:10px;color:#3d5a7a;line-height:1.7;border-bottom:1px solid #0d1929;padding-bottom:4px;margin-bottom:4px}
.log-entry:last-child{border-bottom:none;margin-bottom:0}
.log-entry.new{color:var(--accent)}

/* ── SECRETS TABLE ── */
.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden}
.table-top{
  background:var(--surface2);border-bottom:1px solid var(--border);
  padding:14px 24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px
}
.filters{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.chip{
  font-family:var(--mono);font-size:10px;letter-spacing:1px;
  padding:5px 14px;border-radius:20px;border:1px solid var(--border);
  background:transparent;color:var(--muted);cursor:pointer;transition:all .2s
}
.chip.active,.chip:hover{border-color:var(--accent);color:var(--accent);background:#00e5ff11}
.chip.f-expired.active{border-color:var(--red);color:var(--red);background:#ff3d6b11}
.chip.f-critical.active{border-color:var(--orange);color:var(--orange);background:#ff8c4211}
.chip.f-warning.active{border-color:var(--yellow);color:var(--yellow);background:#ffcb4711}
.chip.f-ok.active{border-color:var(--green);color:var(--green);background:#00f59311}
.search-box{
  background:var(--surface);border:1px solid var(--border);color:var(--text);
  font-family:var(--mono);font-size:11px;padding:6px 12px;border-radius:4px;outline:none;width:180px;
  transition:border-color .2s
}
.search-box:focus{border-color:var(--accent)}
.count-badge{font-family:var(--mono);font-size:11px;color:var(--accent)}

table{width:100%;border-collapse:collapse}
thead th{
  font-family:var(--mono);font-size:9px;letter-spacing:2px;color:var(--muted);
  text-transform:uppercase;text-align:left;padding:12px 20px;
  border-bottom:1px solid var(--border);background:var(--surface2)
}
tbody tr{border-bottom:1px solid #0c1826;transition:background .15s;animation:fadeRow .3s ease both}
@keyframes fadeRow{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
tbody tr:hover{background:#0d1c2e}
tbody td{padding:13px 20px;font-size:13px;vertical-align:middle}
.secret-name{font-family:var(--mono);font-size:12px;color:var(--text)}
.proj-tag{
  font-family:var(--mono);font-size:10px;padding:3px 9px;border-radius:3px;
  background:#00e5ff0d;border:1px solid #00e5ff1a;color:var(--accent)
}
.exp-date{font-family:var(--mono);font-size:11px;color:var(--text)}
.badge{
  display:inline-flex;align-items:center;gap:6px;font-family:var(--mono);font-size:11px;
  padding:4px 11px;border-radius:20px;font-weight:bold
}
.badge.expired {background:#ff3d6b18;color:var(--red);border:1px solid #ff3d6b33}
.badge.critical{background:#ff8c4218;color:var(--orange);border:1px solid #ff8c4233}
.badge.warning {background:#ffcb4718;color:var(--yellow);border:1px solid #ffcb4733}
.badge.ok      {background:#00f59318;color:var(--green);border:1px solid #00f59333}
.badge.no_expiry{background:#3d5a7a18;color:var(--muted);border:1px solid #3d5a7a33}
.dot{width:6px;height:6px;border-radius:50%;display:inline-block;flex-shrink:0}
.dot.expired {background:var(--red);box-shadow:0 0 6px var(--red)}
.dot.critical{background:var(--orange);box-shadow:0 0 6px var(--orange)}
.dot.warning {background:var(--yellow);box-shadow:0 0 6px var(--yellow);animation:blink 1.5s infinite}
.dot.ok      {background:var(--green);box-shadow:0 0 6px var(--green)}
.dot.no_expiry{background:var(--muted)}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}
.bar-wrap{width:70px;height:3px;background:var(--border);border-radius:2px;overflow:hidden}
.bar-fill{height:100%;border-radius:2px;transition:width .6s ease}

/* empty */
.empty{text-align:center;padding:50px;color:var(--muted)}
.empty-icon{font-size:40px;margin-bottom:10px}
.empty p{font-family:var(--mono);font-size:12px;letter-spacing:1px}

/* loading */
#overlay{
  position:fixed;inset:0;background:var(--bg);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  z-index:9999;transition:opacity .4s
}
#overlay.gone{opacity:0;pointer-events:none}
.spinner{width:56px;height:56px;border:2px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite;margin-bottom:16px}
@keyframes spin{to{transform:rotate(360deg)}}
.load-text{font-family:var(--mono);font-size:11px;letter-spacing:3px;color:var(--muted);text-transform:uppercase}

/* toast */
#toast{
  position:fixed;bottom:22px;right:22px;
  background:var(--surface2);border:1px solid var(--accent);border-radius:8px;
  padding:12px 20px;font-family:var(--mono);font-size:12px;color:var(--accent);
  z-index:9999;transform:translateY(70px);opacity:0;transition:all .3s cubic-bezier(.34,1.56,.64,1)
}
#toast.show{transform:translateY(0);opacity:1}

@media(max-width:1100px){.cols{grid-template-columns:1fr}.stats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.stats{grid-template-columns:repeat(2,1fr)};main{padding:16px}}
</style>
</head>
<body>

<div id="overlay">
  <div class="spinner"></div>
  <div class="load-text">Scanning Vault...</div>
</div>
<div id="toast"></div>

<header>
  <div class="brand">
    <div class="brand-icon">🔐</div>
    <div>
      <div class="brand-title">Secret Vault Monitor</div>
      <div class="brand-sub">GCP SECRET MANAGER &nbsp;·&nbsp; <span id="project-label">loading...</span></div>
    </div>
  </div>
  <div class="header-right">
    <div class="scan-time">LAST SCAN: <span id="scan-time-val">—</span></div>
    <button class="btn btn-refresh" onclick="loadData()">⟳ Refresh</button>
    <button class="btn btn-alert" onclick="sendAlert()">📣 Send Alert</button>
  </div>
</header>

<main>

  <!-- Stat Cards -->
  <div class="stats">
    <div class="card total"><div class="card-label">Total Secrets</div><div class="card-val" id="s-total">—</div><div class="card-sub">all secrets</div></div>
    <div class="card expired"><div class="card-label">Expired</div><div class="card-val" id="s-expired">—</div><div class="card-sub">past expiry</div></div>
    <div class="card critical"><div class="card-label">Critical</div><div class="card-val" id="s-critical">—</div><div class="card-sub">≤ 7 days</div></div>
    <div class="card warning"><div class="card-label">Warning</div><div class="card-val" id="s-warning">—</div><div class="card-sub">8–10 days</div></div>
    <div class="card ok"><div class="card-label">Healthy</div><div class="card-val" id="s-ok">—</div><div class="card-sub">safe</div></div>
    <div class="card noexp"><div class="card-label">No Expiry</div><div class="card-val" id="s-noexp">—</div><div class="card-sub">permanent</div></div>
  </div>

  <div class="cols">

    <!-- Secrets Table -->
    <div>
      <div class="table-wrap">
        <div class="table-top">
          <div class="filters">
            <button class="chip active" onclick="setFilter('all',this)">ALL</button>
            <button class="chip f-expired" onclick="setFilter('expired',this)">EXPIRED</button>
            <button class="chip f-critical" onclick="setFilter('critical',this)">CRITICAL</button>
            <button class="chip f-warning" onclick="setFilter('warning',this)">WARNING</button>
            <button class="chip f-ok" onclick="setFilter('ok',this)">HEALTHY</button>
            <input class="search-box" type="text" placeholder="search secret..." oninput="renderTable()"/>
          </div>
          <span class="count-badge" id="count-badge">0 secrets</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Status</th><th>Secret Name</th><th>Project</th>
              <th>Expiry Date</th><th>Days Left</th><th>Timeline</th>
            </tr>
          </thead>
          <tbody id="tbody"></tbody>
        </table>
      </div>
    </div>

    <!-- Scheduler Panel -->
    <div>
      <div class="panel">
        <div class="panel-head">
          <span class="panel-title">⏱ Auto Scheduler</span>
          <span class="status-pill running" id="sched-pill">● RUNNING</span>
        </div>
        <div class="panel-body">
          <div class="sched-row"><span class="sched-label">Project</span><span class="sched-val accent" id="sc-project">—</span></div>
          <div class="sched-row"><span class="sched-label">Total Runs</span><span class="sched-val" id="sc-runs">—</span></div>
          <div class="sched-row"><span class="sched-label">Alerts Sent</span><span class="sched-val green" id="sc-alerts">—</span></div>
          <div class="sched-row"><span class="sched-label">Last Run</span><span class="sched-val" id="sc-last">—</span></div>

          <div class="countdown-wrap">
            <div class="countdown-ring">
              <svg width="100" height="100" viewBox="0 0 100 100">
                <circle class="ring-bg" cx="50" cy="50" r="42"/>
                <circle class="ring-fill" id="ring-arc" cx="50" cy="50" r="42"
                  stroke="var(--accent)"
                  stroke-dasharray="263.9"
                  stroke-dashoffset="0"/>
              </svg>
              <div class="ring-text">
                <div class="ring-num" id="ring-num">—</div>
                <div class="ring-unit">SECONDS</div>
              </div>
            </div>
          </div>
          <div style="text-align:center;margin-bottom:14px">
            <span style="font-family:var(--mono);font-size:10px;color:var(--muted);letter-spacing:1px">NEXT SCAN IN</span>
          </div>

          <div class="log-title">Recent Activity</div>
          <div class="log-box" id="log-box">
            <div class="log-entry">Waiting for first scan...</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>

<script>
let allSecrets = [];
let currentFilter = 'all';
let maxInterval = 60;

// ── Load secrets data ──────────────────────────────────────────
async function loadData() {
  try {
    const r = await fetch('/api/secrets');
    const d = await r.json();
    allSecrets = d.secrets;

    document.getElementById('project-label').textContent = d.project;
    document.getElementById('scan-time-val').textContent = d.last_updated;
    document.getElementById('s-total').textContent    = d.summary.total;
    document.getElementById('s-expired').textContent  = d.summary.expired;
    document.getElementById('s-critical').textContent = d.summary.critical;
    document.getElementById('s-warning').textContent  = d.summary.warning;
    document.getElementById('s-ok').textContent       = d.summary.ok;
    document.getElementById('s-noexp').textContent    = d.summary.no_expiry;

    renderTable();
  } catch(e) {
    toast('❌ Error loading secrets');
    console.error(e);
  } finally {
    document.getElementById('overlay').classList.add('gone');
  }
}

// ── Load scheduler state ───────────────────────────────────────
async function loadScheduler() {
  try {
    const r = await fetch('/api/scheduler');
    const d = await r.json();
    maxInterval = d.interval;

    document.getElementById('sc-project').textContent = d.project;
    document.getElementById('sc-runs').textContent    = d.total_runs;
    document.getElementById('sc-alerts').textContent  = d.alerts_sent;
    document.getElementById('sc-last').textContent    = d.last_run_utc || '—';

    // pill
    const pill = document.getElementById('sched-pill');
    pill.textContent = d.running ? '● RUNNING' : '● STOPPED';
    pill.className   = 'status-pill ' + (d.running ? 'running' : 'stopped');

    // countdown ring
    const sec = d.next_run_in || 0;
    const circumference = 263.9;
    const offset = circumference - (sec / maxInterval) * circumference;
    document.getElementById('ring-arc').style.strokeDashoffset = offset;
    document.getElementById('ring-num').textContent = sec;

    // log
    const logBox = document.getElementById('log-box');
    if (d.log && d.log.length) {
      logBox.innerHTML = d.log.map((e, i) =>
        `<div class="log-entry ${i===0?'new':''}">${esc(e)}</div>`
      ).join('');
    }
  } catch(e) { /* silently skip */ }
}

// ── Table render ──────────────────────────────────────────────
function setFilter(f, el) {
  currentFilter = f;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  renderTable();
}

function renderTable() {
  const search = document.querySelector('.search-box').value.toLowerCase();
  const order  = {expired:0,critical:1,warning:2,ok:3,no_expiry:4};

  let filtered = allSecrets
    .filter(s => {
      const matchF = currentFilter === 'all' || s.status === currentFilter;
      const matchS = !search || s.name.toLowerCase().includes(search);
      return matchF && matchS;
    })
    .sort((a, b) => order[a.status] - order[b.status]);

  document.getElementById('count-badge').textContent = `${filtered.length} secret${filtered.length!==1?'s':''}`;
  const tbody = document.getElementById('tbody');

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty"><div class="empty-icon">✅</div><p>No secrets match this filter</p></div></td></tr>`;
    return;
  }

  const barColor = {expired:'#ff3d6b',critical:'#ff8c42',warning:'#ffcb47',ok:'#00f593',no_expiry:'#3d5a7a'};

  tbody.innerHTML = filtered.map((s, i) => {
    const dText  = s.days_left === null ? '—' : s.days_left < 0 ? `${Math.abs(s.days_left)}d overdue` : `${s.days_left}d`;
    const barPct = s.days_left === null ? 100 : Math.max(0, Math.min(100, (s.days_left / 30) * 100));
    const stLabel = s.status === 'no_expiry' ? 'NONE' : s.status.toUpperCase();
    return `
    <tr style="animation-delay:${i*.03}s">
      <td><span class="dot ${s.status}"></span> <span style="font-family:var(--mono);font-size:9px;letter-spacing:1px;color:var(--muted)">${stLabel}</span></td>
      <td><span class="secret-name">${esc(s.name)}</span></td>
      <td><span class="proj-tag">${esc(s.project)}</span></td>
      <td><span class="exp-date">${s.expire_time}</span></td>
      <td><span class="badge ${s.status}"><span class="dot ${s.status}"></span>${dText}</span></td>
      <td><div class="bar-wrap"><div class="bar-fill" style="width:${barPct}%;background:${barColor[s.status]||'#3d5a7a'}"></div></div></td>
    </tr>`;
  }).join('');
}

// ── Manual alert ──────────────────────────────────────────────
async function sendAlert() {
  try {
    const r = await fetch('/api/trigger-alert', {method:'POST'});
    const d = await r.json();
    toast(`✅ Alert triggered — ${d.alerts_sent} secret(s) notified`);
  } catch(e) { toast('❌ Alert failed'); }
}

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3500);
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Poll loops ────────────────────────────────────────────────
loadData();
setInterval(loadData, 5 * 60 * 1000);       // refresh secrets every 5 min

loadScheduler();
setInterval(loadScheduler, 1000);            // update scheduler ring every 1s
</script>
</body>
</html>"""


# ── Routes ────────────────────────────────────────────────────

@app.route("/")
def index():
    return Response(DASHBOARD_HTML, mimetype="text/html")


@app.route("/api/secrets")
def api_secrets():
    data = metrics.get_metrics()
    return jsonify(data)


@app.route("/api/scheduler")
def api_scheduler():
    state = scheduler.get_state()
    state["project"]  = config.GCP_PROJECT_ID
    state["interval"] = config.SCHEDULER_INTERVAL_SECONDS
    return jsonify(state)


@app.route("/api/trigger-alert", methods=["POST"])
def api_trigger_alert():
    data     = metrics.get_metrics()
    expiring = data["expiring"]
    sent     = scheduler.send_teams_alert(expiring)
    return jsonify({"status": "ok", "alerts_sent": sent})


@app.route("/api/health")
def api_health():
    return jsonify({"status": "healthy", "project": config.GCP_PROJECT_ID})


# ── Entry point ───────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  🔐 GCP Secret Vault Monitor")
    print(f"  Project  : {config.GCP_PROJECT_ID}")
    print(f"  URL      : http://localhost:{config.PORT}")
    print(f"  Interval : every {config.SCHEDULER_INTERVAL_SECONDS}s")
    print("=" * 55)
    app.run(debug=False, host=config.HOST, port=config.PORT)

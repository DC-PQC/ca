# =============================================================
#  scheduler.py  —  Background auto-check & alert engine
# =============================================================

import threading
import time
import json
import requests
from datetime import datetime, timezone
import config
import metrics


# ── Shared state (read by dashboard.py) ──────────────────────
scheduler_state = {
    "running":       False,
    "last_run":      None,
    "last_run_utc":  None,
    "alerts_sent":   0,
    "total_runs":    0,
    "next_run_in":   config.SCHEDULER_INTERVAL_SECONDS,
    "log":           [],          # last 10 scheduler events
}

_thread = None
_stop_event = threading.Event()


# ── Teams alert ───────────────────────────────────────────────

def send_teams_alert(expiring):
    if not config.TEAMS_WEBHOOK_URL or not expiring:
        _log(f"Teams skip — webhook empty or no expiring secrets ({len(expiring)} found)")
        return 0

    rows = "".join(
        f"| **{s['project']}** | {s['name']} | {s['expire_time']} | ⚠️ {s['days_left']} days |\n"
        for s in expiring
    )
    payload = {
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        "themeColor": "FF4444",
        "summary": "GCP Secret Expiry Alert",
        "sections": [{
            "activityTitle":    "🔐 GCP Secret Manager – Expiry Alert",
            "activitySubtitle": f"Secrets expiring within {config.WARN_MIN_DAYS}–{config.WARN_MAX_DAYS} days",
            "text": (
                f"| Project | Secret | Expires | Days Left |\n"
                f"|---|---|---|---|\n{rows}"
            ),
            "markdown": True,
        }],
    }
    try:
        resp = requests.post(
            config.TEAMS_WEBHOOK_URL,
            headers={"Content-Type": "application/json"},
            data=json.dumps(payload),
            timeout=10
        )
        _log(f"Teams alert sent for {len(expiring)} secret(s) — HTTP {resp.status_code}")
        return len(expiring)
    except Exception as e:
        _log(f"Teams alert FAILED: {e}")
        return 0


# ── Internal log ──────────────────────────────────────────────

def _log(msg):
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
    entry = f"[{ts}] {msg}"
    print(f"[scheduler] {entry}")
    scheduler_state["log"].insert(0, entry)
    scheduler_state["log"] = scheduler_state["log"][:10]  # keep last 10


# ── Main loop ─────────────────────────────────────────────────

def _run_loop():
    scheduler_state["running"] = True
    _log("Scheduler started")

    while not _stop_event.is_set():
        # ── Run check ──────────────────────────────────────────
        _log("Running secret expiry check...")
        try:
            data     = metrics.get_metrics()
            expiring = data["expiring"]
            summary  = data["summary"]

            _log(
                f"Scan complete — total:{summary['total']} "
                f"expired:{summary['expired']} "
                f"critical:{summary['critical']} "
                f"warning:{summary['warning']}"
            )

            sent = send_teams_alert(expiring)
            scheduler_state["alerts_sent"] += sent

        except Exception as e:
            _log(f"Check failed: {e}")

        scheduler_state["total_runs"]   += 1
        scheduler_state["last_run_utc"]  = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        # ── Countdown to next run ──────────────────────────────
        for remaining in range(config.SCHEDULER_INTERVAL_SECONDS, 0, -1):
            if _stop_event.is_set():
                break
            scheduler_state["next_run_in"] = remaining
            time.sleep(1)

    scheduler_state["running"] = False
    _log("Scheduler stopped")


# ── Public API ────────────────────────────────────────────────

def start():
    global _thread
    if scheduler_state["running"]:
        return
    _stop_event.clear()
    _thread = threading.Thread(target=_run_loop, daemon=True)
    _thread.start()


def stop():
    _stop_event.set()


def get_state():
    return dict(scheduler_state)

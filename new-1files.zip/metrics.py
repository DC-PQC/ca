# =============================================================
#  metrics.py  —  Fetches secrets & computes all metrics
# =============================================================

from datetime import datetime, timezone
from google.cloud import secretmanager
import config


def fetch_secrets():
    """Connect to GCP Secret Manager and return all secrets with status."""
    client = secretmanager.SecretManagerServiceClient()
    now = datetime.now(timezone.utc)
    secrets = []

    try:
        parent = f"projects/{config.GCP_PROJECT_ID}"
        for secret in client.list_secrets(request={"parent": parent}):
            name        = secret.name.split("/")[-1]
            expire_time = secret.expire_time
            labels      = dict(secret.labels) if secret.labels else {}

            if expire_time:
                days_left = (expire_time - now).days

                if days_left < 0:
                    status = "expired"
                elif days_left <= config.WARN_MIN_DAYS:
                    status = "critical"
                elif days_left <= config.WARN_MAX_DAYS:
                    status = "warning"
                else:
                    status = "ok"

                secrets.append({
                    "name":        name,
                    "project":     config.GCP_PROJECT_ID,
                    "expire_time": expire_time.strftime("%Y-%m-%d %H:%M UTC"),
                    "days_left":   days_left,
                    "status":      status,
                    "labels":      labels,
                })
            else:
                secrets.append({
                    "name":        name,
                    "project":     config.GCP_PROJECT_ID,
                    "expire_time": "No expiry set",
                    "days_left":   None,
                    "status":      "no_expiry",
                    "labels":      labels,
                })

    except Exception as e:
        print(f"[metrics] ERROR fetching secrets: {e}")

    return secrets


def compute_summary(secrets):
    """Return a dict of counts per status."""
    return {
        "total":     len(secrets),
        "expired":   sum(1 for s in secrets if s["status"] == "expired"),
        "critical":  sum(1 for s in secrets if s["status"] == "critical"),
        "warning":   sum(1 for s in secrets if s["status"] == "warning"),
        "ok":        sum(1 for s in secrets if s["status"] == "ok"),
        "no_expiry": sum(1 for s in secrets if s["status"] == "no_expiry"),
    }


def get_expiring(secrets):
    """Return only secrets that need attention."""
    return [s for s in secrets if s["status"] in ("expired", "critical", "warning")]


def get_metrics():
    """Single call — returns everything the dashboard and scheduler need."""
    secrets = fetch_secrets()
    summary = compute_summary(secrets)
    expiring = get_expiring(secrets)
    return {
        "secrets":      secrets,
        "summary":      summary,
        "expiring":     expiring,
        "project":      config.GCP_PROJECT_ID,
        "last_updated": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
    }

# =============================================================
#  config.py  —  EDIT ONLY THIS FILE FOR YOUR DEMO
# =============================================================

# ── 🔧 YOUR PROJECT ID (only thing you need to change) ────────
GCP_PROJECT_ID = "prefab-bounty-480110-d2"

# ── Alert thresholds ──────────────────────────────────────────
WARN_MIN_DAYS = 7    # Critical if expiring within 7 days
WARN_MAX_DAYS = 10   # Warning if expiring within 10 days

# ── Teams webhook (optional — leave blank to skip) ────────────
TEAMS_WEBHOOK_URL = ""

# ── Scheduler (auto-alert interval in seconds) ────────────────
SCHEDULER_INTERVAL_SECONDS = 60   # Check every 60s for demo
                                   # Change to 86400 for daily in prod

# ── Dashboard server ──────────────────────────────────────────
HOST = "0.0.0.0"
PORT = 8080

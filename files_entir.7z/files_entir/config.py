"""
config.py - All configuration loaded from environment variables.
On GCP VM, set these in /opt/cscrf/.env
"""
import os


class Config:
    # Flask
    SECRET_KEY   = os.getenv("FLASK_SECRET_KEY", "change-me-in-production")
    REQUIRE_AUTH = os.getenv("REQUIRE_AUTH", "false").lower() == "true"

    # Microsoft Entra - only needed if REQUIRE_AUTH=true
    ENTRA_CLIENT_ID     = os.getenv("ENTRA_CLIENT_ID", "")
    ENTRA_CLIENT_SECRET = os.getenv("ENTRA_CLIENT_SECRET", "")
    ENTRA_TENANT_ID     = os.getenv("ENTRA_TENANT_ID", "")
    OIDC_REDIRECT_URI   = os.getenv("OIDC_REDIRECT_URI", "")
    ENTRA_AUTHORITY     = f"https://login.microsoftonline.com/{os.getenv('ENTRA_TENANT_ID','')}"

    # GCP Projects - comma separated list of all projects to scan
    GCP_ORG_ID      = os.getenv("GCP_ORG_ID", "")
    GCP_PROJECT_IDS = os.getenv("GCP_PROJECT_IDS", "")

    # Exclusions
    EXCLUDED_FOLDERS:     list = []
    EXCLUDED_PROJECT_IDS: list = []

    # Scheduler - all daily
    INVENTORY_REFRESH_HOURS     = 24
    CERTIFICATE_MONITOR_HOURS   = 24
    KMS_MONITOR_HOURS           = 24
    SECRET_MONITOR_HOURS        = 24
    VULNERABILITY_COLLECT_HOURS = 24

    # Certificate expiry warning threshold (days)
    CERT_EXPIRY_WARNING_DAYS = int(os.getenv("CERT_EXPIRY_WARNING_DAYS", "30"))

    # HRMS (optional)
    HRMS_API_URL      = os.getenv("HRMS_API_URL", "")
    HRMS_API_KEY      = os.getenv("HRMS_API_KEY", "")
    HRMS_API_USERNAME = os.getenv("HRMS_API_USERNAME", "")
    HRMS_API_PASSWORD = os.getenv("HRMS_API_PASSWORD", "")

    # MFA / Remote Access (optional)
    RAC_API_URL       = os.getenv("RAC_API_URL", "")
    RAC_API_KEY       = os.getenv("RAC_API_KEY", "")
    RAC_API_USERNAME  = os.getenv("RAC_API_USERNAME", "")
    RAC_API_PASSWORD  = os.getenv("RAC_API_PASSWORD", "")
    RAC_AUDIT_LOG_PROJECT            = os.getenv("RAC_AUDIT_LOG_PROJECT", "")
    RAC_INCLUDE_IDENTITY_AWARE_PROXY = os.getenv("RAC_INCLUDE_IDENTITY_AWARE_PROXY", "true").lower() == "true"

    # SIEM (optional)
    SIEM_TYPE                      = os.getenv("SIEM_TYPE", "google-secops")
    SIEM_API_URL                   = os.getenv("SIEM_API_URL", "")
    SIEM_API_KEY                   = os.getenv("SIEM_API_KEY", "")
    SIEM_API_USERNAME              = os.getenv("SIEM_API_USERNAME", "")
    SIEM_API_PASSWORD              = os.getenv("SIEM_API_PASSWORD", "")
    CRITICAL_ASSET_LABEL_KEY       = os.getenv("CRITICAL_ASSET_LABEL_KEY", "criticality")
    CRITICAL_ASSET_LABEL_VALUE     = os.getenv("CRITICAL_ASSET_LABEL_VALUE", "critical")
    SIEM_INTEGRATION_CHECK_PROJECT = os.getenv("SIEM_INTEGRATION_CHECK_PROJECT", "")


def validate_config():
    missing = []
    if not os.getenv("GCP_PROJECT_IDS") and not os.getenv("GCP_ORG_ID"):
        missing.append("GCP_PROJECT_IDS")
    if Config.REQUIRE_AUTH:
        for v in ["ENTRA_CLIENT_ID", "ENTRA_CLIENT_SECRET", "ENTRA_TENANT_ID", "OIDC_REDIRECT_URI"]:
            if not os.getenv(v):
                missing.append(v)
    if missing:
        raise RuntimeError(f"Missing required config: {', '.join(missing)}")

#!/bin/bash
# ============================================================
# full_setup.sh - Complete CSCRF Setup Script
# Run this from your LOCAL machine where gcloud is installed
#
# What this does:
#   1. Creates service account
#   2. Grants roles on all 8 projects
#   3. Creates GCP VM
#   4. Attaches service account to VM
#   5. Uploads your files to VM
#   6. Deploys and starts the dashboard
#
# Usage:
#   1. Edit the CONFIGURATION section below
#   2. Place this script in same folder as your project files
#   3. bash full_setup.sh
# ============================================================

set -e

# ============================================================
# CONFIGURATION - EDIT THESE VALUES
# ============================================================

# Project where the VM and service account will be created
MAIN_PROJECT="prefab-bounty-480110-d2"

# Your 8 GCP project IDs to scan
PROJECTS=(
    "project-id-1"
    "project-id-2"
    "project-id-3"
    "project-id-4"
    "project-id-5"
    "project-id-6"
    "project-id-7"
    "project-id-8"
)

# VM settings
VM_NAME="cscrf-dashboard"
VM_ZONE="asia-south1-a"
VM_MACHINE_TYPE="e2-medium"
VM_IMAGE_FAMILY="debian-12"
VM_IMAGE_PROJECT="debian-cloud"
VM_DISK_SIZE="20GB"

# Service account
SA_NAME="cscrf-monitor"

# Local folder containing your project files
FILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ============================================================
# DO NOT EDIT BELOW THIS LINE
# ============================================================

SA_EMAIL="$SA_NAME@$MAIN_PROJECT.iam.gserviceaccount.com"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

info()    { echo -e "${GREEN}[INFO]${NC}  $1"; }
step()    { echo -e "${BLUE}[STEP]${NC}  $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo "=============================================="
echo "   CSCRF Dashboard - Full GCP Setup"
echo "=============================================="
echo ""
echo "  Main Project : $MAIN_PROJECT"
echo "  VM Name      : $VM_NAME"
echo "  VM Zone      : $VM_ZONE"
echo "  Projects     : ${#PROJECTS[@]} projects to scan"
echo ""
read -p "  Press ENTER to continue or Ctrl+C to cancel..."
echo ""

# ── Verify gcloud is logged in ────────────────────────────────
step "Verifying gcloud authentication..."
ACTIVE_ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null)
if [ -z "$ACTIVE_ACCOUNT" ]; then
    error "Not logged into gcloud. Run: gcloud auth login"
fi
info "Logged in as: $ACTIVE_ACCOUNT"

# Set default project
gcloud config set project $MAIN_PROJECT --quiet
info "Active project: $MAIN_PROJECT"
echo ""

# ── Step 1: Enable required APIs ─────────────────────────────
step "Step 1/6: Enabling required GCP APIs..."
gcloud services enable \
    compute.googleapis.com \
    iam.googleapis.com \
    cloudresourcemanager.googleapis.com \
    privateca.googleapis.com \
    cloudkms.googleapis.com \
    secretmanager.googleapis.com \
    securitycenter.googleapis.com \
    --project=$MAIN_PROJECT --quiet
info "APIs enabled"
echo ""

# ── Step 2: Create Service Account ───────────────────────────
step "Step 2/6: Creating service account..."
if gcloud iam service-accounts describe $SA_EMAIL --project=$MAIN_PROJECT &>/dev/null; then
    info "Service account already exists: $SA_EMAIL"
else
    gcloud iam service-accounts create $SA_NAME \
        --display-name="CSCRF Dashboard Monitor" \
        --description="Read-only monitor for CSCRF security dashboard" \
        --project=$MAIN_PROJECT
    info "Service account created: $SA_EMAIL"
fi
echo ""

# ── Step 3: Grant IAM roles on all projects ───────────────────
step "Step 3/6: Granting IAM roles on all ${#PROJECTS[@]} projects..."
echo ""

# Read-only roles needed for monitoring
ROLES=(
    "roles/privateca.auditor"              # Read CAS certificates & CAs
    "roles/cloudkms.viewer"                # Read KMS keyrings & keys
    "roles/secretmanager.viewer"           # Read Secret Manager secrets
    "roles/secretmanager.secretAccessor"   # Access secret versions (to check state)
    "roles/securitycenter.findingsViewer"  # Read SCC vulnerability findings
    "roles/viewer"                         # General read access
)

for PROJECT in "${PROJECTS[@]}"; do
    echo "  ── Project: $PROJECT"

    # Enable required APIs on each project
    for API in privateca.googleapis.com cloudkms.googleapis.com secretmanager.googleapis.com; do
        gcloud services enable $API --project=$PROJECT --quiet 2>/dev/null || \
            warning "    Could not enable $API on $PROJECT (may need billing)"
    done

    # Grant each role
    for ROLE in "${ROLES[@]}"; do
        gcloud projects add-iam-policy-binding "$PROJECT" \
            --member="serviceAccount:$SA_EMAIL" \
            --role="$ROLE" \
            --quiet 2>/dev/null \
            && echo -e "    ${GREEN}+${NC} $ROLE" \
            || warning "    Could not grant $ROLE on $PROJECT"
    done
    echo ""
done
info "IAM roles granted on all projects"
echo ""

# ── Step 4: Create VM ─────────────────────────────────────────
step "Step 4/6: Creating VM '$VM_NAME'..."
if gcloud compute instances describe $VM_NAME --zone=$VM_ZONE --project=$MAIN_PROJECT &>/dev/null; then
    info "VM '$VM_NAME' already exists, skipping creation"
else
    gcloud compute instances create $VM_NAME \
        --project=$MAIN_PROJECT \
        --zone=$VM_ZONE \
        --machine-type=$VM_MACHINE_TYPE \
        --image-family=$VM_IMAGE_FAMILY \
        --image-project=$VM_IMAGE_PROJECT \
        --boot-disk-size=$VM_DISK_SIZE \
        --boot-disk-type=pd-balanced \
        --service-account=$SA_EMAIL \
        --scopes=https://www.googleapis.com/auth/cloud-platform \
        --tags=cscrf-dashboard \
        --metadata=enable-oslogin=true
    info "VM created: $VM_NAME"

    info "Waiting 30 seconds for VM to boot..."
    sleep 30
fi
echo ""

# ── Create firewall rule for port 5000 ────────────────────────
step "Creating firewall rule for port 5000..."
if gcloud compute firewall-rules describe allow-cscrf-dashboard --project=$MAIN_PROJECT &>/dev/null; then
    info "Firewall rule already exists"
else
    gcloud compute firewall-rules create allow-cscrf-dashboard \
        --project=$MAIN_PROJECT \
        --allow=tcp:5000 \
        --target-tags=cscrf-dashboard \
        --description="Allow CSCRF dashboard access on port 5000" \
        --source-ranges=0.0.0.0/0
    info "Firewall rule created"
fi
echo ""

# ── Step 5: Upload project files ──────────────────────────────
step "Step 5/6: Uploading project files to VM..."

# Create remote directory structure
gcloud compute ssh $VM_NAME --zone=$VM_ZONE --project=$MAIN_PROJECT \
    --command="mkdir -p /tmp/cscrf/blueprints /tmp/cscrf/templates" \
    --quiet

# Upload core Python files
for f in main.py config.py auth.py inventory.py metrics.py scheduler.py gcp_crypto_monitor.py requirements.txt; do
    if [ -f "$FILES_DIR/$f" ]; then
        gcloud compute scp "$FILES_DIR/$f" $VM_NAME:/tmp/cscrf/$f \
            --zone=$VM_ZONE --project=$MAIN_PROJECT --quiet
        info "  Uploaded: $f"
    else
        warning "  Missing: $f — upload manually later"
    fi
done

# Upload blueprints
for f in __init__.py dashboard.py health.py; do
    if [ -f "$FILES_DIR/blueprints/$f" ]; then
        gcloud compute scp "$FILES_DIR/blueprints/$f" $VM_NAME:/tmp/cscrf/blueprints/$f \
            --zone=$VM_ZONE --project=$MAIN_PROJECT --quiet
        info "  Uploaded: blueprints/$f"
    else
        warning "  Missing: blueprints/$f"
    fi
done

# Upload template
if [ -f "$FILES_DIR/templates/dashboard.html" ]; then
    gcloud compute scp "$FILES_DIR/templates/dashboard.html" \
        $VM_NAME:/tmp/cscrf/templates/dashboard.html \
        --zone=$VM_ZONE --project=$MAIN_PROJECT --quiet
    info "  Uploaded: templates/dashboard.html"
fi

# Upload deploy script and service file
for f in deploy.sh cscrf.service cscrf.env; do
    if [ -f "$FILES_DIR/$f" ]; then
        gcloud compute scp "$FILES_DIR/$f" $VM_NAME:/tmp/cscrf/$f \
            --zone=$VM_ZONE --project=$MAIN_PROJECT --quiet
        info "  Uploaded: $f"
    fi
done

info "All files uploaded to /tmp/cscrf on VM"
echo ""

# ── Step 6: Run deploy on VM ──────────────────────────────────
step "Step 6/6: Running deployment on VM..."

# Build project IDs string for .env
PROJECT_IDS=$(IFS=','; echo "${PROJECTS[*]}")

gcloud compute ssh $VM_NAME --zone=$VM_ZONE --project=$MAIN_PROJECT --command="
set -e

echo '--- Installing system packages ---'
sudo apt-get update -qq
sudo apt-get install -y python3-pip python3-venv python3-dev build-essential

echo '--- Creating cscrf user ---'
sudo id -u cscrf &>/dev/null || sudo useradd -r -s /bin/false -d /opt/cscrf cscrf

echo '--- Setting up directories ---'
sudo mkdir -p /opt/cscrf/blueprints
sudo mkdir -p /opt/cscrf/templates
sudo mkdir -p /var/log/cscrf

echo '--- Copying files ---'
sudo cp /tmp/cscrf/*.py /opt/cscrf/
sudo cp /tmp/cscrf/requirements.txt /opt/cscrf/
sudo cp /tmp/cscrf/blueprints/*.py /opt/cscrf/blueprints/
sudo cp /tmp/cscrf/templates/dashboard.html /opt/cscrf/templates/

echo '--- Creating .env file ---'
sudo tee /opt/cscrf/.env > /dev/null << 'ENVEOF'
FLASK_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))' 2>/dev/null || echo 'change-me-please')
REQUIRE_AUTH=false
GCP_PROJECT_IDS=$PROJECT_IDS
CERT_EXPIRY_WARNING_DAYS=30
HRMS_API_URL=
HRMS_API_KEY=
RAC_API_URL=
RAC_API_KEY=
SIEM_TYPE=google-secops
SIEM_API_URL=
SIEM_API_KEY=
ENVEOF
sudo chmod 600 /opt/cscrf/.env

echo '--- Setting up Python venv ---'
cd /opt/cscrf
sudo python3 -m venv venv
sudo venv/bin/pip install --upgrade pip -q
sudo venv/bin/pip install -r requirements.txt -q

echo '--- Setting permissions ---'
sudo chown -R cscrf:cscrf /opt/cscrf
sudo chown -R cscrf:cscrf /var/log/cscrf

echo '--- Installing systemd service ---'
sudo cp /tmp/cscrf/cscrf.service /etc/systemd/system/cscrf.service
sudo systemctl daemon-reload
sudo systemctl enable cscrf
sudo systemctl restart cscrf

echo '--- Done ---'
" --quiet

info "Deployment complete"
echo ""

# ── Final Summary ─────────────────────────────────────────────
EXTERNAL_IP=$(gcloud compute instances describe $VM_NAME \
    --zone=$VM_ZONE \
    --project=$MAIN_PROJECT \
    --format="value(networkInterfaces[0].accessConfigs[0].natIP)" 2>/dev/null)

echo ""
echo "=============================================="
echo -e "  ${GREEN}Setup Complete!${NC}"
echo "=============================================="
echo ""
echo "  Service Account : $SA_EMAIL"
echo "  VM Name         : $VM_NAME"
echo "  VM Zone         : $VM_ZONE"
echo "  External IP     : $EXTERNAL_IP"
echo ""
echo "  Dashboard  : http://$EXTERNAL_IP:5000"
echo "  Health     : http://$EXTERNAL_IP:5000/health"
echo ""
echo "  Useful commands:"
echo "    SSH into VM  : gcloud compute ssh $VM_NAME --zone=$VM_ZONE"
echo "    View logs    : sudo journalctl -u cscrf -f"
echo "    Restart      : sudo systemctl restart cscrf"
echo "    Status       : sudo systemctl status cscrf"
echo ""
echo -e "  ${YELLOW}Note: Dashboard refreshes all 8 projects every 24 hours${NC}"
echo -e "  ${YELLOW}      No gcloud login needed - VM service account used${NC}"
echo "=============================================="
echo ""

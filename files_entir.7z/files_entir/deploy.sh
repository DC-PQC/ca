#!/bin/bash
# ============================================================
# deploy.sh - CSCRF Dashboard GCP VM Deployment Script
#
# Run this ON your GCP VM:
#   sudo bash deploy.sh
#
# Before running:
#   1. Upload all project files to VM
#   2. Edit cscrf.env with your 8 project IDs
# ============================================================
set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# Must run as root
[ "$EUID" -ne 0 ] && error "Please run as root: sudo bash deploy.sh"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/opt/cscrf"
LOG_DIR="/var/log/cscrf"
SERVICE_USER="cscrf"

echo ""
echo "============================================"
echo "  CSCRF Dashboard - GCP VM Deployment"
echo "============================================"
echo ""

# ── Step 1: System packages ───────────────────────────────────
info "Step 1/8: Installing system packages..."
apt-get update -qq
apt-get install -y python3-pip python3-venv python3-dev build-essential
info "System packages installed"

# ── Step 2: Create dedicated user ────────────────────────────
info "Step 2/8: Creating service user '$SERVICE_USER'..."
if id "$SERVICE_USER" &>/dev/null; then
    info "User '$SERVICE_USER' already exists"
else
    useradd -r -s /bin/false -d $APP_DIR $SERVICE_USER
    info "User '$SERVICE_USER' created"
fi

# ── Step 3: Create directories ───────────────────────────────
info "Step 3/8: Creating directories..."
mkdir -p $APP_DIR/blueprints
mkdir -p $APP_DIR/templates
mkdir -p $LOG_DIR
info "Directories created"

# ── Step 4: Copy application files ───────────────────────────
info "Step 4/8: Copying application files..."

# Core Python files
for f in main.py config.py auth.py inventory.py metrics.py scheduler.py gcp_crypto_monitor.py requirements.txt; do
    if [ -f "$SCRIPT_DIR/$f" ]; then
        cp "$SCRIPT_DIR/$f" "$APP_DIR/$f"
        info "  Copied: $f"
    else
        warning "  Missing: $f - please upload this file"
    fi
done

# Blueprints
for f in __init__.py dashboard.py health.py; do
    if [ -f "$SCRIPT_DIR/blueprints/$f" ]; then
        cp "$SCRIPT_DIR/blueprints/$f" "$APP_DIR/blueprints/$f"
        info "  Copied: blueprints/$f"
    else
        warning "  Missing: blueprints/$f"
    fi
done

# Templates
if [ -f "$SCRIPT_DIR/templates/dashboard.html" ]; then
    cp "$SCRIPT_DIR/templates/dashboard.html" "$APP_DIR/templates/dashboard.html"
    info "  Copied: templates/dashboard.html"
else
    warning "  Missing: templates/dashboard.html"
fi

# ── Step 5: Environment file ──────────────────────────────────
info "Step 5/8: Setting up environment file..."
if [ -f "$SCRIPT_DIR/cscrf.env" ]; then
    cp "$SCRIPT_DIR/cscrf.env" "$APP_DIR/.env"
    chmod 600 "$APP_DIR/.env"   # only owner can read - protects secrets
    info "  .env file copied - EDIT /opt/cscrf/.env with your 8 project IDs!"
else
    warning "  cscrf.env not found - creating blank .env"
    cat > "$APP_DIR/.env" << 'ENVEOF'
FLASK_SECRET_KEY=REPLACE_WITH_LONG_RANDOM_STRING
REQUIRE_AUTH=false
GCP_PROJECT_IDS=project-id-1,project-id-2,project-id-3,project-id-4,project-id-5,project-id-6,project-id-7,project-id-8
CERT_EXPIRY_WARNING_DAYS=30
ENVEOF
    chmod 600 "$APP_DIR/.env"
fi

# ── Step 6: Python virtual environment ───────────────────────
info "Step 6/8: Setting up Python virtual environment..."
cd $APP_DIR
python3 -m venv venv
venv/bin/pip install --upgrade pip -q
venv/bin/pip install -r requirements.txt
info "Python packages installed"

# ── Step 7: Set permissions ───────────────────────────────────
info "Step 7/8: Setting permissions..."
chown -R $SERVICE_USER:$SERVICE_USER $APP_DIR
chown -R $SERVICE_USER:$SERVICE_USER $LOG_DIR
info "Permissions set"

# ── Step 8: Install and start systemd service ─────────────────
info "Step 8/8: Installing systemd service..."
cp "$SCRIPT_DIR/cscrf.service" /etc/systemd/system/cscrf.service
systemctl daemon-reload
systemctl enable cscrf
systemctl restart cscrf

# ── Final status ──────────────────────────────────────────────
sleep 3
STATUS=$(systemctl is-active cscrf)

echo ""
echo "============================================"
if [ "$STATUS" = "active" ]; then
    echo -e "  ${GREEN}Deployment Successful!${NC}"
    echo "============================================"
    echo ""
    EXTERNAL_IP=$(curl -s -H "Metadata-Flavor: Google" \
        http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip \
        2>/dev/null || hostname -I | awk '{print $1}')
    echo "  Dashboard : http://$EXTERNAL_IP:5000"
    echo "  Health    : http://$EXTERNAL_IP:5000/health"
    echo ""
    echo "  Useful commands:"
    echo "    View logs  : sudo journalctl -u cscrf -f"
    echo "    Restart    : sudo systemctl restart cscrf"
    echo "    Stop       : sudo systemctl stop cscrf"
    echo "    Status     : sudo systemctl status cscrf"
    echo ""
    echo -e "  ${YELLOW}IMPORTANT: Edit /opt/cscrf/.env with your 8 real project IDs${NC}"
    echo "  Then run: sudo systemctl restart cscrf"
else
    echo -e "  ${RED}Service failed to start!${NC}"
    echo "============================================"
    echo ""
    echo "  Check logs: sudo journalctl -u cscrf -n 50"
fi
echo "============================================"
echo ""

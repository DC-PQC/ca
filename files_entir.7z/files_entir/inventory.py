"""
inventory.py - GCP project discovery.
Uses VM service account automatically via google.auth.default()
No gcloud login or key files needed on GCP VM.
"""
import logging
import threading
from datetime import datetime
from typing import List, Dict
import os

from config import Config

logger = logging.getLogger(__name__)

_inventory_lock = threading.Lock()
_inventory_state: Dict = {
    "last_refreshed": None,
    "projects": [],
}


def build_inventory() -> None:
    logger.info("Building GCP project inventory...")
    projects = _discover_projects()
    with _inventory_lock:
        _inventory_state["projects"] = projects
        _inventory_state["last_refreshed"] = datetime.utcnow()
    logger.info(f"Inventory complete: {len(projects)} project(s) found.")
    for p in projects:
        logger.info(f"  -> {p['project_id']} ({p['display_name']})")


def get_inventory() -> Dict:
    with _inventory_lock:
        return _inventory_state.copy()


def _discover_projects() -> List[Dict]:
    """
    Priority order:
    1. GCP_PROJECT_IDS env var (comma-separated) - recommended for 8 projects
    2. Org-level discovery via GCP_ORG_ID (if numeric org ID)
    3. Treat GCP_ORG_ID as single project ID (fallback)
    """

    # --- Strategy 1: Explicit project list (best for your 8 projects) ---
    explicit = os.getenv("GCP_PROJECT_IDS", "").strip()
    if explicit:
        projects = []
        for pid in [p.strip() for p in explicit.split(",") if p.strip()]:
            projects.append({
                "project_id":    pid,
                "project_number": "",
                "display_name":  pid,
                "parent":        "",
            })
        logger.info(f"Using explicit project list ({len(projects)} projects)")
        return projects

    # --- Strategy 2: Org-level discovery ---
    org_id = Config.GCP_ORG_ID
    if org_id and org_id.isdigit():
        logger.info(f"Trying org-level discovery for org: {org_id}")
        projects = _discover_from_org(org_id)
        if projects:
            return projects
        logger.warning("Org discovery returned no projects, falling back...")

    # --- Strategy 3: Single project fallback ---
    if org_id:
        logger.info(f"Using GCP_ORG_ID as single project ID: {org_id}")
        return [{
            "project_id":    org_id,
            "project_number": "",
            "display_name":  org_id,
            "parent":        "",
        }]

    logger.error("No GCP projects configured! Set GCP_PROJECT_IDS in .env")
    return []


def _discover_from_org(org_id: str) -> List[Dict]:
    try:
        from googleapiclient import discovery
        import google.auth
        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform.read-only"]
        )
        crm = discovery.build("cloudresourcemanager", "v3", credentials=credentials)
        all_projects = []
        request = crm.projects().search(query=f"parent:organizations/{org_id}")
        while request is not None:
            response = request.execute()
            for project in response.get("projects", []):
                pid    = project.get("projectId", "")
                parent = project.get("parent", "")
                if pid in Config.EXCLUDED_PROJECT_IDS:
                    continue
                if any(parent == f"folders/{fid}" for fid in Config.EXCLUDED_FOLDERS):
                    continue
                if project.get("state") != "ACTIVE":
                    continue
                all_projects.append({
                    "project_id":    pid,
                    "project_number": project.get("name", "").split("/")[-1],
                    "display_name":  project.get("displayName", pid),
                    "parent":        parent,
                })
            request = crm.projects().search_next(request, response)
        return all_projects
    except Exception as exc:
        logger.warning(f"Org-level discovery failed: {exc}")
        return []

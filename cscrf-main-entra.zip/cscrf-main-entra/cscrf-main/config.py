import os


class Config:
    # Flask
    SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "change-me-in-production")

    # ── Auth Mode ──────────────────────────────────────────────────────────────
    # "local"  → username/password (default, works without Entra)
    # "entra"  → Microsoft Entra ID SSO (set when you have App Registration)
    AUTH_MODE = os.getenv("AUTH_MODE", "local").lower()

    # ── Local auth (used when AUTH_MODE=local) ─────────────────────────────────
    DASHBOARD_USERNAME = os.getenv("DASHBOARD_USERNAME", "admin")
    DASHBOARD_PASSWORD = os.getenv("DASHBOARD_PASSWORD")

    # ── Microsoft Entra SSO (used when AUTH_MODE=entra) ────────────────────────
    ENTRA_CLIENT_ID     = os.getenv("ENTRA_CLIENT_ID", "")
    ENTRA_CLIENT_SECRET = os.getenv("ENTRA_CLIENT_SECRET", "")
    ENTRA_TENANT_ID     = os.getenv("ENTRA_TENANT_ID", "")

    # Full callback URL — must match exactly what you register in Azure portal
    # e.g. http://35.188.133.34:5000/auth/callback
    OIDC_REDIRECT_URI   = os.getenv("OIDC_REDIRECT_URI", "")

    # Optional: restrict to specific Azure AD group IDs (comma-separated)
    # Leave empty to allow ALL users in your tenant
    # e.g. ENTRA_ALLOWED_GROUPS=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    _raw_groups = os.getenv("ENTRA_ALLOWED_GROUPS", "")
    ENTRA_ALLOWED_GROUPS = [g.strip() for g in _raw_groups.split(",") if g.strip()]

    # ── GCP Projects ───────────────────────────────────────────────────────────
    GCP_ORG_ID = os.getenv("GCP_ORG_ID", "")
    _raw_project_ids = os.getenv("GCP_PROJECT_IDS", "")
    GCP_PROJECT_IDS = [p.strip() for p in _raw_project_ids.split(",") if p.strip()]

    # ── Exclusions ─────────────────────────────────────────────────────────────
    EXCLUDED_FOLDERS     = [os.getenv("GCP_PLAYGROUND_FOLDER_ID")]
    EXCLUDED_PROJECT_IDS: list = []

    INVENTORY_REFRESH_HOURS = 6

    # ── HRMS ───────────────────────────────────────────────────────────────────
    HRMS_API_URL      = os.getenv("HRMS_API_URL")
    HRMS_API_KEY      = os.getenv("HRMS_API_KEY")
    HRMS_API_USERNAME = os.getenv("HRMS_API_USERNAME")
    HRMS_API_PASSWORD = os.getenv("HRMS_API_PASSWORD")

    # ── RAC / MFA ──────────────────────────────────────────────────────────────
    RAC_API_URL        = os.getenv("RAC_API_URL")
    RAC_API_KEY        = os.getenv("RAC_API_KEY")
    RAC_API_USERNAME   = os.getenv("RAC_API_USERNAME")
    RAC_API_PASSWORD   = os.getenv("RAC_API_PASSWORD")
    RAC_AUDIT_LOG_PROJECT         = os.getenv("RAC_AUDIT_LOG_PROJECT", "")
    RAC_INCLUDE_IDENTITY_AWARE_PROXY = os.getenv("RAC_INCLUDE_IDENTITY_AWARE_PROXY", "true").lower() == "true"

    # ── SIEM ───────────────────────────────────────────────────────────────────
    SIEM_TYPE          = os.getenv("SIEM_TYPE", "google-secops")
    SIEM_API_URL       = os.getenv("SIEM_API_URL")
    SIEM_API_KEY       = os.getenv("SIEM_API_KEY")
    SIEM_API_USERNAME  = os.getenv("SIEM_API_USERNAME")
    SIEM_API_PASSWORD  = os.getenv("SIEM_API_PASSWORD")
    CRITICAL_ASSET_LABEL_KEY   = os.getenv("CRITICAL_ASSET_LABEL_KEY", "criticality")
    CRITICAL_ASSET_LABEL_VALUE = os.getenv("CRITICAL_ASSET_LABEL_VALUE", "critical")
    SIEM_INTEGRATION_CHECK_PROJECT = os.getenv("SIEM_INTEGRATION_CHECK_PROJECT", "")


def validate_config():
    missing = []

    if not os.getenv("FLASK_SECRET_KEY"):
        missing.append("FLASK_SECRET_KEY")

    if not os.getenv("GCP_ORG_ID") and not os.getenv("GCP_PROJECT_IDS"):
        missing.append("GCP_ORG_ID or GCP_PROJECT_IDS")

    auth_mode = os.getenv("AUTH_MODE", "local").lower()

    if auth_mode == "local":
        if not os.getenv("DASHBOARD_PASSWORD"):
            missing.append("DASHBOARD_PASSWORD")

    elif auth_mode == "entra":
        for var in ["ENTRA_CLIENT_ID", "ENTRA_CLIENT_SECRET", "ENTRA_TENANT_ID", "OIDC_REDIRECT_URI"]:
            if not os.getenv(var):
                missing.append(var)

    if missing:
        raise RuntimeError(f"Missing required env vars: {', '.join(missing)}")

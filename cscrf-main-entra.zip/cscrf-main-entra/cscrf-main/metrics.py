"""
Metrics collection for security and compliance monitoring.

Collects:
1. Vulnerability metrics from GCP Security Command Center (SCC)
   Formula: (Vulnerabilities Mitigated / Vulnerabilities Identified) * 100

2. Security Training metrics from HRMS API
   Formula: (Personnel Trained / Total Personnel) * 100
"""
import logging
from datetime import datetime
from typing import Dict, List, Optional
from google.cloud import securitycenter_v1
from google.oauth2 import service_account
import threading
import requests
from requests.auth import HTTPBasicAuth, HTTPDigestAuth

logger = logging.getLogger(__name__)

_metrics_lock = threading.Lock()
_metrics_state = {
    "last_collected": None,
    "vulnerabilities_identified": 0,
    "vulnerabilities_mitigated": 0,
    "remediation_percentage": 0.0,
    "by_project": {},  # {project_id: {identified, mitigated, percentage}}
    "vulnerabilities": [],  # List of vulnerability findings
    "security_training": {
        "last_collected": None,
        "total_personnel": 0,
        "personnel_trained": 0,
        "training_percentage": 0.0,
        "training_details": []  # List of personnel training records
    },
    "mfa_remote_access": {
        "last_collected": None,
        "total_remote_users": 0,
        "remote_users_with_mfa": 0,
        "mfa_percentage": 0.0,
        "mfa_details": [],  # List of remote access records with MFA status
        "by_application": {}  # {app_name: {total, with_mfa, percentage}}
    },
    "critical_assets_siem": {
        "last_collected": None,
        "total_critical_assets": 0,
        "critical_assets_integrated": 0,
        "integration_percentage": 0.0,
        "assets_details": [],  # List of critical assets and their SIEM integration status
        "by_type": {},  # {resource_type: {total, integrated, percentage}}
        "by_project": {}  # {project_id: {total, integrated, percentage}}
    }
}


def init_scc_client():
    """Initialize Security Command Center client."""
    try:
        client = securitycenter_v1.SecurityCenterClient()
        return client
    except Exception as e:
        logger.error(f"Failed to initialize SCC client: {e}")
        return None


def collect_vulnerability_metrics(organization_id: str) -> Dict:
    """
    Collect vulnerability metrics from GCP Security Command Center.
    
    Args:
        organization_id: GCP organization ID (e.g., "123456789")
        
    Returns:
        Dictionary with vulnerability metrics
    """
    client = init_scc_client()
    if not client:
        logger.error("SCC client not available")
        return _get_empty_metrics()
    
    try:
        parent = f"organizations/{organization_id}"
        
        # Query for vulnerability findings
        query = "resource_properties.resource_type = \"gce_instance\""
        
        findings = []
        identified_count = 0
        mitigated_count = 0
        by_project = {}
        
        # List findings from the organization
        request = securitycenter_v1.ListFindingsRequest(
            parent=parent,
            filter='category = "VULNERABILITY"'
        )
        
        page_result = client.list_findings(request=request)
        
        for finding_result in page_result:
            finding = finding_result.finding
            project_id = finding.resource.project_id
            
            # Initialize project entry if not exists
            if project_id not in by_project:
                by_project[project_id] = {
                    "identified": 0,
                    "mitigated": 0,
                    "percentage": 0.0,
                    "details": []
                }
            
            # Count findings
            identified_count += 1
            by_project[project_id]["identified"] += 1
            
            # Check if vulnerability is mitigated (state = RESOLVED or similar)
            is_mitigated = finding.state == securitycenter_v1.Finding.State.RESOLVED
            if is_mitigated:
                mitigated_count += 1
                by_project[project_id]["mitigated"] += 1
            
            # Store finding details
            finding_detail = {
                "project_id": project_id,
                "resource_name": finding.resource.name,
                "category": finding.category,
                "severity": securitycenter_v1.Finding.Severity(finding.severity).name,
                "state": securitycenter_v1.Finding.State(finding.state).name,
                "description": finding.description,
                "created_time": str(finding.create_time),
                "is_mitigated": is_mitigated
            }
            findings.append(finding_detail)
        
        # Calculate remediation percentage for each project
        for proj_id in by_project:
            identified = by_project[proj_id]["identified"]
            mitigated = by_project[proj_id]["mitigated"]
            percentage = (mitigated / identified * 100) if identified > 0 else 0.0
            by_project[proj_id]["percentage"] = round(percentage, 2)
        
        # Calculate overall remediation percentage
        overall_percentage = (mitigated_count / identified_count * 100) if identified_count > 0 else 0.0
        
        metrics = {
            "last_collected": datetime.utcnow(),
            "vulnerabilities_identified": identified_count,
            "vulnerabilities_mitigated": mitigated_count,
            "remediation_percentage": round(overall_percentage, 2),
            "by_project": by_project,
            "vulnerabilities": findings
        }
        
        logger.info(
            f"Collected vulnerability metrics: "
            f"Identified={identified_count}, Mitigated={mitigated_count}, "
            f"Remediation={overall_percentage:.2f}%"
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error collecting vulnerability metrics: {e}")
        return _get_empty_metrics()


def collect_vulnerability_metrics_from_projects(projects: List[Dict]) -> Dict:
    """
    Collect vulnerability metrics for a list of projects.
    Falls back to direct API calls if SCC is not available.
    
    Args:
        projects: List of project dictionaries with 'project_id'
        
    Returns:
        Dictionary with vulnerability metrics
    """
    client = init_scc_client()
    if not client:
        logger.warning("SCC client not available, using fallback metrics")
        return _get_empty_metrics()
    
    try:
        identified_count = 0
        mitigated_count = 0
        by_project = {}
        findings = []
        
        for project in projects:
            project_id = project.get("project_id")
            if not project_id:
                continue
            
            by_project[project_id] = {
                "identified": 0,
                "mitigated": 0,
                "percentage": 0.0,
                "details": []
            }
            
            try:
                # Query findings for this specific project
                request = securitycenter_v1.ListFindingsRequest(
                    parent=f"projects/{project_id}",
                    filter='category = "VULNERABILITY"'
                )
                
                page_result = client.list_findings(request=request)
                
                for finding_result in page_result:
                    finding = finding_result.finding
                    identified_count += 1
                    by_project[project_id]["identified"] += 1
                    
                    is_mitigated = finding.state == securitycenter_v1.Finding.State.RESOLVED
                    if is_mitigated:
                        mitigated_count += 1
                        by_project[project_id]["mitigated"] += 1
                    
                    finding_detail = {
                        "project_id": project_id,
                        "resource_name": finding.resource.name,
                        "category": finding.category,
                        "severity": securitycenter_v1.Finding.Severity(finding.severity).name,
                        "state": securitycenter_v1.Finding.State(finding.state).name,
                        "description": finding.description,
                        "created_time": str(finding.create_time),
                        "is_mitigated": is_mitigated
                    }
                    findings.append(finding_detail)
            
            except Exception as e:
                logger.warning(f"Error collecting metrics for project {project_id}: {e}")
            
            # Calculate percentage for this project
            identified = by_project[project_id]["identified"]
            mitigated = by_project[project_id]["mitigated"]
            percentage = (mitigated / identified * 100) if identified > 0 else 0.0
            by_project[project_id]["percentage"] = round(percentage, 2)
        
        # Calculate overall percentage
        overall_percentage = (mitigated_count / identified_count * 100) if identified_count > 0 else 0.0
        
        metrics = {
            "last_collected": datetime.utcnow(),
            "vulnerabilities_identified": identified_count,
            "vulnerabilities_mitigated": mitigated_count,
            "remediation_percentage": round(overall_percentage, 2),
            "by_project": by_project,
            "vulnerabilities": findings
        }
        
        logger.info(
            f"Collected vulnerability metrics from {len(projects)} projects: "
            f"Identified={identified_count}, Mitigated={mitigated_count}, "
            f"Remediation={overall_percentage:.2f}%"
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error collecting vulnerability metrics: {e}")
        return _get_empty_metrics()


def get_vulnerability_metrics() -> Dict:
    """Get current cached vulnerability metrics."""
    with _metrics_lock:
        return _metrics_state.copy()


def update_vulnerability_metrics(metrics: Dict):
    """Update cached vulnerability metrics."""
    with _metrics_lock:
        _metrics_state.update(metrics)
        logger.debug("Vulnerability metrics updated")


def _get_empty_metrics() -> Dict:
    """Return empty metrics structure."""
    return {
        "last_collected": None,
        "vulnerabilities_identified": 0,
        "vulnerabilities_mitigated": 0,
        "remediation_percentage": 0.0,
        "by_project": {},
        "vulnerabilities": []
    }


__all__ = [
    "collect_vulnerability_metrics",
    "collect_vulnerability_metrics_from_projects",
    "get_vulnerability_metrics",
    "update_vulnerability_metrics",
    "collect_security_training_metrics",
    "get_security_training_metrics",
    "update_security_training_metrics"
]


# ============================================================================
# Security Training Metrics Collection from HRMS
# ============================================================================

def collect_security_training_metrics(hrms_url: str, hrms_key: str = None, 
                                     hrms_username: str = None, 
                                     hrms_password: str = None) -> Dict:
    """
    Collect security training metrics from HRMS API.
    
    Formula: (Personnel Trained / Total Personnel) * 100
    
    Args:
        hrms_url: Base URL for HRMS API
        hrms_key: Optional API key for authentication
        hrms_username: Optional username for basic/digest auth
        hrms_password: Optional password for basic/digest auth
        
    Returns:
        Dictionary with security training metrics
    """
    try:
        if not hrms_url:
            logger.warning("HRMS API URL not configured")
            return _get_empty_training_metrics()
        
        # Prepare authentication
        auth = None
        headers = {"Content-Type": "application/json"}
        
        if hrms_key:
            headers["Authorization"] = f"Bearer {hrms_key}"
        elif hrms_username and hrms_password:
            auth = HTTPBasicAuth(hrms_username, hrms_password)
        
        # Call HRMS API to get personnel training data
        # Adjust endpoint based on your HRMS API structure
        endpoints = [
            f"{hrms_url}/api/security-training",
            f"{hrms_url}/security/training-metrics",
            f"{hrms_url}/personnel/training-status"
        ]
        
        response = None
        for endpoint in endpoints:
            try:
                response = requests.get(
                    endpoint,
                    headers=headers,
                    auth=auth,
                    timeout=10,
                    verify=True
                )
                if response.status_code == 200:
                    break
            except requests.RequestException:
                continue
        
        if not response or response.status_code != 200:
            logger.error(f"Failed to fetch security training data from HRMS: {hrms_url}")
            return _get_empty_training_metrics()
        
        data = response.json()
        
        # Parse response based on common HRMS API formats
        total_personnel = data.get("total_personnel") or data.get("total_count") or 0
        personnel_trained = data.get("personnel_trained") or data.get("trained_count") or 0
        training_details = data.get("personnel") or data.get("training_records") or []
        
        # Handle nested structure if present
        if isinstance(data.get("data"), dict):
            total_personnel = total_personnel or data["data"].get("total_personnel", 0)
            personnel_trained = personnel_trained or data["data"].get("personnel_trained", 0)
            training_details = training_details or data["data"].get("personnel", [])
        
        # Calculate training percentage
        training_percentage = (personnel_trained / total_personnel * 100) if total_personnel > 0 else 0.0
        
        metrics = {
            "last_collected": datetime.utcnow(),
            "total_personnel": total_personnel,
            "personnel_trained": personnel_trained,
            "training_percentage": round(training_percentage, 2),
            "training_details": training_details
        }
        
        logger.info(
            f"Collected security training metrics: "
            f"Total={total_personnel}, Trained={personnel_trained}, "
            f"Percentage={training_percentage:.2f}%"
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error collecting security training metrics: {e}")
        return _get_empty_training_metrics()


def get_security_training_metrics() -> Dict:
    """Get current cached security training metrics."""
    with _metrics_lock:
        return _metrics_state.get("security_training", _get_empty_training_metrics()).copy()


def update_security_training_metrics(metrics: Dict):
    """Update cached security training metrics."""
    with _metrics_lock:
        _metrics_state["security_training"] = metrics
        logger.debug("Security training metrics updated")


def _get_empty_training_metrics() -> Dict:
    """Return empty security training metrics structure."""
    return {
        "last_collected": None,
        "total_personnel": 0,
        "personnel_trained": 0,
        "training_percentage": 0.0,
        "training_details": []
    }

# ============================================================================
# MFA / Remote Access Control Metrics Collection
# ============================================================================

def collect_mfa_metrics(rac_url: str = None, rac_key: str = None,
                       rac_username: str = None, rac_password: str = None,
                       audit_log_project: str = None,
                       include_iap: bool = True) -> Dict:
    """
    Collect Multi-Factor Authentication (MFA) metrics for remote access.
    
    Formula: (Remote users with MFA / Total remote users) * 100
    
    Collects data from:
    1. External RAC/VPN system API
    2. GCP Cloud Audit Logs (sign-in events)
    3. GCP Identity-Aware Proxy (IAP) logs
    
    Args:
        rac_url: Optional URL for dedicated RAC/VPN monitoring API
        rac_key: Optional API key for RAC API
        rac_username: Optional username for RAC API basic auth
        rac_password: Optional password for RAC API basic auth
        audit_log_project: GCP project ID for Cloud Audit Logs
        include_iap: Whether to include GCP Identity-Aware Proxy data
        
    Returns:
        Dictionary with MFA metrics
    """
    try:
        total_remote_users = 0
        remote_users_with_mfa = 0
        mfa_details = []
        by_application = {}
        
        # Try to collect from external RAC API first
        if rac_url:
            try:
                rac_metrics = _collect_from_rac_api(rac_url, rac_key, rac_username, rac_password)
                total_remote_users += rac_metrics.get("total", 0)
                remote_users_with_mfa += rac_metrics.get("with_mfa", 0)
                mfa_details.extend(rac_metrics.get("details", []))
                
                if rac_metrics.get("by_application"):
                    for app_name, app_data in rac_metrics["by_application"].items():
                        if app_name not in by_application:
                            by_application[app_name] = {"total": 0, "with_mfa": 0, "percentage": 0.0}
                        by_application[app_name]["total"] += app_data.get("total", 0)
                        by_application[app_name]["with_mfa"] += app_data.get("with_mfa", 0)
                        
                logger.info(f"Collected MFA data from RAC API: {remote_users_with_mfa}/{total_remote_users}")
            except Exception as e:
                logger.warning(f"Failed to collect from RAC API: {e}")
        
        # Collect from GCP Cloud Audit Logs
        try:
            gcp_metrics = _collect_from_gcp_audit_logs(audit_log_project, include_iap)
            
            # Merge GCP metrics
            gcp_total = gcp_metrics.get("total", 0)
            gcp_with_mfa = gcp_metrics.get("with_mfa", 0)
            
            if total_remote_users == 0:
                # If no RAC API data, use GCP as primary
                total_remote_users = gcp_total
                remote_users_with_mfa = gcp_with_mfa
                mfa_details = gcp_metrics.get("details", [])
                by_application = gcp_metrics.get("by_application", {})
            else:
                # Combine with existing data
                total_remote_users += gcp_total
                remote_users_with_mfa += gcp_with_mfa
                mfa_details.extend(gcp_metrics.get("details", []))
                
                for app_name, app_data in gcp_metrics.get("by_application", {}).items():
                    if app_name not in by_application:
                        by_application[app_name] = {"total": 0, "with_mfa": 0, "percentage": 0.0}
                    by_application[app_name]["total"] += app_data.get("total", 0)
                    by_application[app_name]["with_mfa"] += app_data.get("with_mfa", 0)
                    
            logger.info(f"Collected MFA data from GCP Audit Logs: {gcp_with_mfa}/{gcp_total}")
        except Exception as e:
            logger.warning(f"Failed to collect from GCP Audit Logs: {e}")
        
        # Calculate percentages
        mfa_percentage = (remote_users_with_mfa / total_remote_users * 100) if total_remote_users > 0 else 0.0
        
        for app_name in by_application:
            app_data = by_application[app_name]
            app_total = app_data.get("total", 0)
            app_with_mfa = app_data.get("with_mfa", 0)
            app_data["percentage"] = (app_with_mfa / app_total * 100) if app_total > 0 else 0.0
        
        metrics = {
            "last_collected": datetime.utcnow(),
            "total_remote_users": total_remote_users,
            "remote_users_with_mfa": remote_users_with_mfa,
            "mfa_percentage": round(mfa_percentage, 2),
            "mfa_details": mfa_details,
            "by_application": by_application
        }
        
        logger.info(
            f"Collected MFA metrics: "
            f"Total={total_remote_users}, With MFA={remote_users_with_mfa}, "
            f"Percentage={mfa_percentage:.2f}%"
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error collecting MFA metrics: {e}")
        return _get_empty_mfa_metrics()


def _collect_from_rac_api(rac_url: str, rac_key: str = None,
                         rac_username: str = None, rac_password: str = None) -> Dict:
    """Collect MFA metrics from external RAC/VPN API."""
    try:
        auth = None
        headers = {"Content-Type": "application/json"}
        
        if rac_key:
            headers["Authorization"] = f"Bearer {rac_key}"
        elif rac_username and rac_password:
            auth = HTTPBasicAuth(rac_username, rac_password)
        
        endpoints = [
            f"{rac_url}/api/mfa-metrics",
            f"{rac_url}/api/remote-access/mfa-status",
            f"{rac_url}/mfa/statistics"
        ]
        
        response = None
        for endpoint in endpoints:
            try:
                response = requests.get(
                    endpoint,
                    headers=headers,
                    auth=auth,
                    timeout=10,
                    verify=True
                )
                if response.status_code == 200:
                    break
            except requests.RequestException:
                continue
        
        if not response or response.status_code != 200:
            logger.warning(f"Failed to fetch MFA data from RAC API: {rac_url}")
            return {"total": 0, "with_mfa": 0, "details": [], "by_application": {}}
        
        data = response.json()
        
        total = data.get("total_users") or data.get("total_remote_users") or 0
        with_mfa = data.get("users_with_mfa") or data.get("mfa_enabled_users") or 0
        details = data.get("user_details") or data.get("records") or []
        by_app = data.get("by_application") or data.get("applications") or {}
        
        return {
            "total": total,
            "with_mfa": with_mfa,
            "details": details,
            "by_application": by_app
        }
        
    except Exception as e:
        logger.warning(f"Error collecting from RAC API: {e}")
        return {"total": 0, "with_mfa": 0, "details": [], "by_application": {}}


def _collect_from_gcp_audit_logs(project_id: str = None, include_iap: bool = True) -> Dict:
    """Collect MFA metrics from GCP Cloud Audit Logs and IAP."""
    try:
        if not project_id:
            logger.warning("GCP project ID not provided for audit log collection")
            return {"total": 0, "with_mfa": 0, "details": [], "by_application": {}}
        
        # This would require google-cloud-logging client
        # For now, returning placeholder - in production, implement full audit log querying
        logger.info(f"Querying GCP Audit Logs for project: {project_id}")
        
        # Placeholder - would query Cloud Logging API for:
        # 1. Login audit events with MFA status
        # 2. IAP access logs if include_iap is True
        # 3. VPC Flow Logs for authenticated connections
        
        total = 0
        with_mfa = 0
        details = []
        by_application = {}
        
        # TODO: Implement full GCP audit log collection
        # This requires google-cloud-logging library and appropriate IAM roles
        
        return {
            "total": total,
            "with_mfa": with_mfa,
            "details": details,
            "by_application": by_application
        }
        
    except Exception as e:
        logger.warning(f"Error collecting from GCP Audit Logs: {e}")
        return {"total": 0, "with_mfa": 0, "details": [], "by_application": {}}


def get_mfa_metrics() -> Dict:
    """Get current cached MFA metrics."""
    with _metrics_lock:
        return _metrics_state.get("mfa_remote_access", _get_empty_mfa_metrics()).copy()


def update_mfa_metrics(metrics: Dict):
    """Update cached MFA metrics."""
    with _metrics_lock:
        _metrics_state["mfa_remote_access"] = metrics
        logger.debug("MFA metrics updated")


def _get_empty_mfa_metrics() -> Dict:
    """Return empty MFA metrics structure."""
    return {
        "last_collected": None,
        "total_remote_users": 0,
        "remote_users_with_mfa": 0,
        "mfa_percentage": 0.0,
        "mfa_details": [],
        "by_application": {}
    }

# ============================================================================
# Critical Assets SIEM Integration Metrics
# ============================================================================

def collect_critical_assets_siem_metrics(projects: List[Dict],
                                        siem_type: str = "google-secops",
                                        siem_url: str = None,
                                        siem_key: str = None,
                                        siem_username: str = None,
                                        siem_password: str = None,
                                        critical_label_key: str = "criticality",
                                        critical_label_value: str = "critical") -> Dict:
    """
    Collect critical assets SIEM integration metrics.
    
    Formula: (Critical assets integrated with SIEM / Total critical assets) * 100
    """
    try:
        total_critical_assets = 0
        critical_assets_integrated = 0
        assets_details = []
        by_type = {}
        by_project = {}
        
        logger.info(f"Starting critical assets SIEM collection for {len(projects)} projects")
        
        for project in projects:
            project_id = project.get("project_id")
            if not project_id:
                continue
            
            by_project[project_id] = {
                "total": 0,
                "integrated": 0,
                "percentage": 0.0,
                "details": []
            }
        
        integration_percentage = (
            (critical_assets_integrated / total_critical_assets * 100) 
            if total_critical_assets > 0 else 0.0
        )
        
        for resource_type in by_type:
            type_total = by_type[resource_type]["total"]
            type_integrated = by_type[resource_type]["integrated"]
            by_type[resource_type]["percentage"] = (
                (type_integrated / type_total * 100) if type_total > 0 else 0.0
            )
        
        metrics = {
            "last_collected": datetime.utcnow(),
            "total_critical_assets": total_critical_assets,
            "critical_assets_integrated": critical_assets_integrated,
            "integration_percentage": round(integration_percentage, 2),
            "assets_details": assets_details,
            "by_type": by_type,
            "by_project": by_project
        }
        
        logger.info(
            f"Collected critical assets SIEM metrics: "
            f"Total={total_critical_assets}, Integrated={critical_assets_integrated}, "
            f"Percentage={integration_percentage:.2f}%"
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error collecting critical assets SIEM metrics: {e}")
        return _get_empty_critical_assets_metrics()


def get_critical_assets_siem_metrics() -> Dict:
    """Get current cached critical assets SIEM metrics."""
    with _metrics_lock:
        return _metrics_state.get("critical_assets_siem", _get_empty_critical_assets_metrics()).copy()


def update_critical_assets_siem_metrics(metrics: Dict):
    """Update cached critical assets SIEM metrics."""
    with _metrics_lock:
        _metrics_state["critical_assets_siem"] = metrics
        logger.debug("Critical assets SIEM metrics updated")


def _get_empty_critical_assets_metrics() -> Dict:
    """Return empty critical assets SIEM metrics structure."""
    return {
        "last_collected": None,
        "total_critical_assets": 0,
        "critical_assets_integrated": 0,
        "integration_percentage": 0.0,
        "assets_details": [],
        "by_type": {},
        "by_project": {}
    }

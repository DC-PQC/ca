from inventory import build_inventory
from config import Config, validate_config
from flask import Flask
from auth import init_auth, auth_bp
from blueprints.dashboard import dashboard_bp
from blueprints.health import health_bp
from blueprints.export import export_bp
from scheduler import init_scheduler
import threading
import logging

logging.basicConfig(level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


def create_app():
    validate_config()

    app = Flask(__name__)
    app.config.from_object(Config)

    init_auth(app)
    app.register_blueprint(auth_bp,    url_prefix="/auth")
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(health_bp)
    app.register_blueprint(export_bp)

    build_inventory()

    # Run initial collection in background so dashboard loads fast
    from scheduler import (
        _collect_kms_metrics_job, _collect_certificate_metrics_job,
        _collect_secret_metrics_job, _collect_vulnerability_metrics_job,
    )
    for fn in [_collect_kms_metrics_job, _collect_certificate_metrics_job,
               _collect_secret_metrics_job, _collect_vulnerability_metrics_job]:
        threading.Thread(target=fn, daemon=True).start()

    init_scheduler()
    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

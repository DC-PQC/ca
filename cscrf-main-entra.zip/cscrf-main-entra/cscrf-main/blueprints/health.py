from flask import Blueprint, jsonify
from inventory import get_inventory
from config import Config

health_bp = Blueprint("health", __name__)

@health_bp.route("/health")
def health():
    inventory = get_inventory()
    return jsonify({
        "status": "ok",
        "inventory": {
            "projects": len(inventory["projects"]),
            "last_refreshed": inventory["last_refreshed"]
        },
        "scope": {
            "gcp_org_id": Config.GCP_ORG_ID,
            "excluded_folders": Config.EXCLUDED_FOLDERS
        }
    })

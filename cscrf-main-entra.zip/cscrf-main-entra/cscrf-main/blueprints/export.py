"""
Export blueprint — generates PDF and Excel reports from live dashboard data.

Routes:
  GET /export/excel   → downloads .xlsx
  GET /export/pdf     → downloads .pdf
"""
import io
import logging
from datetime import datetime
from flask import Blueprint, send_file, jsonify
from auth import login_required
from gcp_assets import get_kms_metrics, get_certificate_metrics, get_secret_metrics
from metrics import get_vulnerability_metrics, get_security_training_metrics, get_mfa_metrics

logger = logging.getLogger(__name__)
export_bp = Blueprint("export", __name__)


def _get_all_data():
    return {
        "kms":   get_kms_metrics(),
        "certs": get_certificate_metrics(),
        "secrets": get_secret_metrics(),
        "vulns": get_vulnerability_metrics(),
        "training": get_security_training_metrics(),
        "mfa":   get_mfa_metrics(),
        "generated_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
    }


# ─────────────────────────────────────────────
# Excel Export
# ─────────────────────────────────────────────

@export_bp.route("/export/excel")
@login_required
def export_excel():
    try:
        import openpyxl
        from openpyxl.styles import (PatternFill, Font, Alignment,
                                      Border, Side, GradientFill)
        from openpyxl.utils import get_column_letter
    except ImportError:
        return jsonify({"error": "openpyxl not installed. Run: pip install openpyxl"}), 500

    d = _get_all_data()
    wb = openpyxl.Workbook()
    wb.remove(wb.active)   # remove default sheet

    # ── Styles ──
    DARK_BG   = "0D1B2E"
    CYAN      = "00D4FF"
    GREEN     = "4CAF50"
    YELLOW    = "FFC107"
    RED       = "F44336"
    HEADER_BG = "07111F"
    WHITE     = "E0ECFF"
    SUBHDR_BG = "162033"

    def hdr_font(color=WHITE, bold=True, size=11):
        return Font(name="Calibri", color=color, bold=bold, size=size)

    def cell_font(color="C9D6E8", size=10):
        return Font(name="Calibri", color=color, size=size)

    def fill(hex_color):
        return PatternFill("solid", fgColor=hex_color)

    thin = Side(style="thin", color="1E3A5C")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center")
    left   = Alignment(horizontal="left",   vertical="center")

    def write_sheet_header(ws, title, subtitle=""):
        ws.sheet_view.showGridLines = False
        ws.sheet_properties.tabColor = "0078D4"
        r1 = ws.cell(1, 1, title)
        r1.font = Font(name="Calibri", color=CYAN, bold=True, size=14)
        r1.fill = fill(DARK_BG)
        r1.alignment = left
        if subtitle:
            r2 = ws.cell(2, 1, subtitle)
            r2.font = Font(name="Calibri", color="7A9CC0", size=9)
            r2.fill = fill(DARK_BG)
            r2.alignment = left
        ws.cell(3, 1, f"Generated: {d['generated_at']}").font = Font(color="4A6A8A", size=9)
        ws.cell(3, 1).fill = fill(DARK_BG)
        return 5  # first data row

    def write_table_header(ws, row, cols, widths=None):
        for ci, col in enumerate(cols, 1):
            c = ws.cell(row, ci, col)
            c.font = hdr_font(color=CYAN, size=10)
            c.fill = fill(HEADER_BG)
            c.alignment = center
            c.border = border
            if widths:
                ws.column_dimensions[get_column_letter(ci)].width = widths[ci-1]

    def write_row(ws, row, values, alt=False):
        bg = "0F2035" if alt else DARK_BG
        for ci, val in enumerate(values, 1):
            c = ws.cell(row, ci, val or "—")
            c.font  = cell_font()
            c.fill  = fill(bg)
            c.alignment = left
            c.border = border

    # ════════════════ Sheet 1: Summary ════════════════
    ws = wb.create_sheet("📊 Summary")
    for col in range(1, 6):
        ws.column_dimensions[get_column_letter(col)].width = 28
    ws.row_dimensions[1].height = 30

    start = write_sheet_header(ws, "CSCRF Security Dashboard — Summary", "Cloud Security & Compliance Resource Framework")

    summary_data = [
        ("KMS Keyrings",           d["kms"].get("total_keyrings", 0),           CYAN),
        ("KMS Crypto Keys",         d["kms"].get("total_crypto_keys", 0),        CYAN),
        ("KMS Enabled Versions",    d["kms"].get("total_enabled_versions", 0),   GREEN),
        ("KMS Disabled Versions",   d["kms"].get("total_disabled_versions", 0),  YELLOW),
        ("KMS Destroyed Versions",  d["kms"].get("total_destroyed_versions", 0), RED),
        ("Total Certificates",      d["certs"].get("total", 0),                  WHITE),
        ("Active Certificates",     d["certs"].get("active", 0),                 GREEN),
        ("Expiring Soon (<30d)",    d["certs"].get("expiring_soon", 0),          YELLOW),
        ("Expired Certificates",    d["certs"].get("expired", 0),                RED),
        ("Total Secrets",           d["secrets"].get("total", 0),                WHITE),
        ("Active Secrets",          d["secrets"].get("active", 0),               GREEN),
        ("Disabled Secrets",        d["secrets"].get("disabled", 0),             YELLOW),
        ("Vulnerabilities Found",   d["vulns"].get("vulnerabilities_identified", 0), RED),
        ("Vulnerabilities Mitigated", d["vulns"].get("vulnerabilities_mitigated", 0), GREEN),
        ("Remediation Rate",        f"{d['vulns'].get('remediation_percentage', 0):.1f}%", GREEN),
    ]

    ws.cell(start, 1, "Metric").font   = hdr_font(CYAN)
    ws.cell(start, 1).fill  = fill(HEADER_BG); ws.cell(start, 1).border = border
    ws.cell(start, 2, "Value").font    = hdr_font(CYAN)
    ws.cell(start, 2).fill  = fill(HEADER_BG); ws.cell(start, 2).border = border

    for i, (metric, value, color) in enumerate(summary_data, start + 1):
        bg = "0F2035" if i % 2 == 0 else DARK_BG
        mc = ws.cell(i, 1, metric); mc.font = cell_font(); mc.fill = fill(bg); mc.border = border
        vc = ws.cell(i, 2, value);  vc.font = Font(name="Calibri", color=color, bold=True, size=11)
        vc.fill = fill(bg); vc.alignment = center; vc.border = border

    # ════════════════ Sheet 2: KMS Keys ════════════════
    ws2 = wb.create_sheet("🔑 KMS Keys")
    cols  = ["Project", "Location", "Keyring", "Key Name", "Purpose", "Versions", "Enabled", "Disabled", "Destroyed", "Next Rotation"]
    widths = [28, 14, 20, 20, 18, 10, 10, 10, 10, 18]
    start = write_sheet_header(ws2, "Cloud KMS — Keyrings & Keys")
    write_table_header(ws2, start, cols, widths)
    for i, k in enumerate(d["kms"].get("keys", []), start + 1):
        write_row(ws2, i, [
            k.get("project"), k.get("location"), k.get("keyring"), k.get("key_name"),
            k.get("purpose"), k.get("versions"), k.get("enabled_versions"),
            k.get("disabled_versions"), k.get("destroyed_versions"),
            k.get("next_rotation", "")[:10] if k.get("next_rotation") else "—"
        ], alt=i % 2 == 0)

    # ════════════════ Sheet 3: Certificates ════════════════
    ws3 = wb.create_sheet("📜 Certificates")
    cols  = ["Project", "Location", "CA Pool", "Certificate", "Subject", "Status", "Expires", "Days Left"]
    widths = [28, 14, 18, 22, 30, 14, 14, 10]
    start = write_sheet_header(ws3, "Certificate Authority Service")
    write_table_header(ws3, start, cols, widths)
    for i, c in enumerate(d["certs"].get("certs", []), start + 1):
        dl = c.get("days_left")
        write_row(ws3, i, [
            c.get("project"), c.get("location"), c.get("ca_pool"),
            c.get("name"), c.get("subject"), c.get("status"),
            c.get("not_after", "")[:10], str(dl) + "d" if dl is not None else "—"
        ], alt=i % 2 == 0)

    # ════════════════ Sheet 4: Secrets ════════════════
    ws4 = wb.create_sheet("🔒 Secrets")
    cols  = ["Project", "Secret Name", "Versions", "Latest State", "Created", "Labels"]
    widths = [28, 30, 10, 14, 14, 30]
    start = write_sheet_header(ws4, "Secret Manager")
    write_table_header(ws4, start, cols, widths)
    for i, s in enumerate(d["secrets"].get("secrets", []), start + 1):
        labels = ", ".join(f"{k}={v}" for k, v in s.get("labels", {}).items())
        write_row(ws4, i, [
            s.get("project"), s.get("name"), s.get("version_count"),
            s.get("latest_version_state"), s.get("create_time", "")[:10], labels
        ], alt=i % 2 == 0)

    # ════════════════ Sheet 5: Scheduler Status ════════════════
    ws5 = wb.create_sheet("⏱ Scheduler")
    start = write_sheet_header(ws5, "Scheduler Status — 12-Hour Collection Cycle")
    ws5.column_dimensions["A"].width = 35
    ws5.column_dimensions["B"].width = 15
    ws5.column_dimensions["C"].width = 25

    write_table_header(ws5, start, ["Job Name", "Interval", "Last Collected"], [35, 15, 25])
    jobs = [
        ("Cloud KMS Collection",         "12 hours", str(d["kms"].get("last_collected", "Pending"))[:19]),
        ("Certificate Collection",        "12 hours", str(d["certs"].get("last_collected", "Pending"))[:19]),
        ("Secret Manager Collection",     "12 hours", str(d["secrets"].get("last_collected", "Pending"))[:19]),
        ("Vulnerability Metrics",         "12 hours", str(d["vulns"].get("last_collected", "Pending"))[:19]),
        ("Security Training Metrics",     "12 hours", str(d["training"].get("last_collected", "Pending"))[:19]),
        ("MFA Remote Access Metrics",     "12 hours", str(d["mfa"].get("last_collected", "Pending"))[:19]),
    ]
    for i, (name, interval, last) in enumerate(jobs, start + 1):
        write_row(ws5, i, [name, interval, last], alt=i % 2 == 0)

    # Save to buffer
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    filename = f"CSCRF_Report_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.xlsx"
    return send_file(buf, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ─────────────────────────────────────────────
# PDF Export
# ─────────────────────────────────────────────

@export_bp.route("/export/pdf")
@login_required
def export_pdf():
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable, PageBreak)
        from reportlab.lib.enums import TA_LEFT, TA_CENTER
    except ImportError:
        return jsonify({"error": "reportlab not installed. Run: pip install reportlab"}), 500

    d = _get_all_data()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                            leftMargin=1.5*cm, rightMargin=1.5*cm,
                            topMargin=1.5*cm, bottomMargin=1.5*cm)

    # ── Colours ──
    DARK   = colors.HexColor("#0D1B2E")
    CYAN   = colors.HexColor("#00D4FF")
    GREEN  = colors.HexColor("#4CAF50")
    YELLOW = colors.HexColor("#FFC107")
    RED    = colors.HexColor("#F44336")
    MID    = colors.HexColor("#162033")
    LIGHT  = colors.HexColor("#C9D6E8")
    DIMMED = colors.HexColor("#4A6A8A")
    HDR    = colors.HexColor("#07111F")

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=18,
                                  textColor=CYAN, spaceAfter=4, backColor=DARK)
    h2_style    = ParagraphStyle("h2",    fontName="Helvetica-Bold", fontSize=13,
                                  textColor=CYAN, spaceBefore=14, spaceAfter=6)
    body_style  = ParagraphStyle("body",  fontName="Helvetica",      fontSize=9,
                                  textColor=LIGHT)
    meta_style  = ParagraphStyle("meta",  fontName="Helvetica",      fontSize=8,
                                  textColor=DIMMED)

    def tbl_style(header_rows=1):
        return TableStyle([
            ("BACKGROUND",  (0, 0), (-1, header_rows - 1), HDR),
            ("TEXTCOLOR",   (0, 0), (-1, header_rows - 1), CYAN),
            ("FONTNAME",    (0, 0), (-1, header_rows - 1), "Helvetica-Bold"),
            ("FONTSIZE",    (0, 0), (-1, header_rows - 1), 8),
            ("ALIGN",       (0, 0), (-1, -1),  "LEFT"),
            ("VALIGN",      (0, 0), (-1, -1),  "MIDDLE"),
            ("FONTNAME",    (0, header_rows), (-1, -1), "Helvetica"),
            ("FONTSIZE",    (0, header_rows), (-1, -1), 8),
            ("TEXTCOLOR",   (0, header_rows), (-1, -1), LIGHT),
            ("BACKGROUND",  (0, header_rows), (-1, -1), DARK),
            ("ROWBACKGROUNDS", (0, header_rows), (-1, -1), [DARK, MID]),
            ("GRID",        (0, 0), (-1, -1), 0.3, colors.HexColor("#1E3A5C")),
            ("ROWHEIGHT",   (0, 0), (-1, -1), 16),
            ("TOPPADDING",  (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ])

    story = []

    # Cover
    story.append(Paragraph("CSCRF Security Dashboard Report", title_style))
    story.append(Paragraph("Cloud Security &amp; Compliance Resource Framework", body_style))
    story.append(Paragraph(f"Generated: {d['generated_at']}  ·  Collection interval: Every 12 hours", meta_style))
    story.append(HRFlowable(width="100%", thickness=1, color=CYAN, spaceAfter=12))

    # ── Summary table ──
    story.append(Paragraph("Executive Summary", h2_style))
    sum_data = [
        ["Metric", "Value", "Metric", "Value"],
        ["KMS Keyrings",        str(d["kms"].get("total_keyrings", 0)),
         "Total Certificates",  str(d["certs"].get("total", 0))],
        ["KMS Crypto Keys",     str(d["kms"].get("total_crypto_keys", 0)),
         "Active Certs",        str(d["certs"].get("active", 0))],
        ["Enabled Versions",    str(d["kms"].get("total_enabled_versions", 0)),
         "Expiring Soon",       str(d["certs"].get("expiring_soon", 0))],
        ["Disabled Versions",   str(d["kms"].get("total_disabled_versions", 0)),
         "Expired Certs",       str(d["certs"].get("expired", 0))],
        ["Total Secrets",       str(d["secrets"].get("total", 0)),
         "Vulns Identified",    str(d["vulns"].get("vulnerabilities_identified", 0))],
        ["Active Secrets",      str(d["secrets"].get("active", 0)),
         "Vulns Mitigated",     str(d["vulns"].get("vulnerabilities_mitigated", 0))],
        ["Disabled Secrets",    str(d["secrets"].get("disabled", 0)),
         "Remediation Rate",    f"{d['vulns'].get('remediation_percentage', 0):.1f}%"],
    ]
    t = Table(sum_data, colWidths=[6*cm, 3*cm, 6*cm, 3*cm])
    t.setStyle(tbl_style())
    story.append(t)
    story.append(PageBreak())

    # ── KMS table ──
    story.append(Paragraph("🔑 Cloud KMS — Keyrings &amp; Keys", h2_style))
    kms_rows = [["Project", "Location", "Keyring", "Key Name", "Purpose", "Ver", "Enabled", "Next Rotation"]]
    for k in d["kms"].get("keys", []):
        kms_rows.append([
            k.get("project", ""), k.get("location", ""), k.get("keyring", ""),
            k.get("key_name", ""), k.get("purpose", ""), str(k.get("versions", 0)),
            str(k.get("enabled_versions", 0)),
            k.get("next_rotation", "")[:10] if k.get("next_rotation") else "—",
        ])
    if len(kms_rows) == 1:
        kms_rows.append(["No data collected yet", "", "", "", "", "", "", ""])
    t = Table(kms_rows, colWidths=[5.5*cm, 2.5*cm, 3.5*cm, 3.5*cm, 4*cm, 1.5*cm, 1.8*cm, 2.8*cm])
    t.setStyle(tbl_style())
    story.append(t)
    story.append(PageBreak())

    # ── Certificates table ──
    story.append(Paragraph("📜 Certificate Authority Service", h2_style))
    cert_rows = [["Project", "Location", "CA Pool", "Certificate", "Status", "Expires", "Days Left"]]
    for c in d["certs"].get("certs", []):
        dl = c.get("days_left")
        cert_rows.append([
            c.get("project", ""), c.get("location", ""), c.get("ca_pool", ""),
            c.get("name", ""), c.get("status", ""),
            c.get("not_after", "")[:10], f"{dl}d" if dl is not None else "—",
        ])
    if len(cert_rows) == 1:
        cert_rows.append(["No data collected yet", "", "", "", "", "", ""])
    t = Table(cert_rows, colWidths=[5.5*cm, 2.5*cm, 3.5*cm, 5*cm, 3.5*cm, 3*cm, 2*cm])
    t.setStyle(tbl_style())
    story.append(t)
    story.append(PageBreak())

    # ── Secrets table ──
    story.append(Paragraph("🔒 Secret Manager", h2_style))
    sec_rows = [["Project", "Secret Name", "Versions", "Latest State", "Created"]]
    for s in d["secrets"].get("secrets", []):
        sec_rows.append([
            s.get("project", ""), s.get("name", ""), str(s.get("version_count", 0)),
            s.get("latest_version_state", ""), s.get("create_time", "")[:10],
        ])
    if len(sec_rows) == 1:
        sec_rows.append(["No data collected yet", "", "", "", ""])
    t = Table(sec_rows, colWidths=[6*cm, 8*cm, 2.5*cm, 4*cm, 3.5*cm])
    t.setStyle(tbl_style())
    story.append(t)

    # ── Footer ──
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=DIMMED))
    story.append(Paragraph(
        "CSCRF Dashboard · GCP Workload Identity · Scheduler: Every 12 Hours · Confidential",
        ParagraphStyle("footer", fontName="Helvetica", fontSize=7, textColor=DIMMED, alignment=TA_CENTER)
    ))

    doc.build(story)
    buf.seek(0)
    filename = f"CSCRF_Report_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buf, as_attachment=True, download_name=filename, mimetype="application/pdf")

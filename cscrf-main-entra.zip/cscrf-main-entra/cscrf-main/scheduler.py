"""
Centralized scheduler — all GCP asset collection jobs run every 12 hours.
"""
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from config import Config
from inventory import build_inventory, get_inventory
from metrics import (
    collect_vulnerability_metrics_from_projects, update_vulnerability_metrics,
    collect_security_training_metrics,           update_security_training_metrics,
    collect_mfa_metrics,                         update_mfa_metrics,
    collect_critical_assets_siem_metrics,        update_critical_assets_siem_metrics,
)
from gcp_assets import (
    collect_kms_metrics,         update_kms_metrics,
    collect_certificate_metrics, update_certificate_metrics,
    collect_secret_metrics,      update_secret_metrics,
)

logger = logging.getLogger(__name__)
_scheduler = None

# ── Schedule intervals (hours) ──────────────────────────────────────────────
SCHEDULE_HOURS = 12   # ← all GCP asset jobs run every 12 hours


def init_scheduler():
    global _scheduler
    if _scheduler is not None:
        logger.warning("Scheduler already initialised")
        return _scheduler
    _scheduler = BackgroundScheduler()
    _register_jobs()
    _scheduler.start()
    logger.info(f"Scheduler started — GCP jobs run every {SCHEDULE_HOURS} hours")
    return _scheduler


def _register_jobs():
    every = dict(trigger="interval", hours=SCHEDULE_HOURS,
                 replace_existing=True, max_instances=1)

    _scheduler.add_job(build_inventory,                        id="inventory_refresh",          name="Inventory Refresh",                 **every)
    _scheduler.add_job(_collect_kms_metrics_job,               id="kms_collection",             name="Cloud KMS Collection",              **every)
    _scheduler.add_job(_collect_certificate_metrics_job,       id="certificate_collection",     name="Certificate Collection",            **every)
    _scheduler.add_job(_collect_secret_metrics_job,            id="secret_collection",          name="Secret Manager Collection",         **every)
    _scheduler.add_job(_collect_vulnerability_metrics_job,     id="vulnerability_collection",   name="Vulnerability Metrics",             **every)
    _scheduler.add_job(_collect_security_training_metrics_job, id="security_training",          name="Security Training Metrics",         **every)
    _scheduler.add_job(_collect_mfa_metrics_job,               id="mfa_collection",             name="MFA Metrics",                       **every)
    _scheduler.add_job(_collect_critical_assets_siem_metrics_job, id="siem_collection",         name="Critical Assets SIEM",              **every)

    logger.info(f"Registered 8 jobs — all run every {SCHEDULE_HOURS} hours")


# ── Job wrappers ─────────────────────────────────────────────────────────────

def _collect_kms_metrics_job():
    try:
        projects = get_inventory().get("projects", [])
        if not projects: return
        m = collect_kms_metrics(projects)
        update_kms_metrics(m)
        logger.info(f"[SCHED] KMS: {m['total_keyrings']} keyrings, {m['total_crypto_keys']} keys")
    except Exception as e:
        logger.error(f"[SCHED] KMS job failed: {e}", exc_info=True)

def _collect_certificate_metrics_job():
    try:
        projects = get_inventory().get("projects", [])
        if not projects: return
        m = collect_certificate_metrics(projects)
        update_certificate_metrics(m)
        logger.info(f"[SCHED] Certs: {m['total']} total, {m['expiring_soon']} expiring")
    except Exception as e:
        logger.error(f"[SCHED] Cert job failed: {e}", exc_info=True)

def _collect_secret_metrics_job():
    try:
        projects = get_inventory().get("projects", [])
        if not projects: return
        m = collect_secret_metrics(projects)
        update_secret_metrics(m)
        logger.info(f"[SCHED] Secrets: {m['total']} total, {m['active']} active")
    except Exception as e:
        logger.error(f"[SCHED] Secrets job failed: {e}", exc_info=True)

def _collect_vulnerability_metrics_job():
    try:
        projects = get_inventory().get("projects", [])
        if not projects: return
        m = collect_vulnerability_metrics_from_projects(projects)
        update_vulnerability_metrics(m)
        logger.info(f"[SCHED] Vulns: {m['vulnerabilities_identified']} identified, {m['remediation_percentage']:.1f}% remediated")
    except Exception as e:
        logger.error(f"[SCHED] Vuln job failed: {e}", exc_info=True)

def _collect_security_training_metrics_job():
    try:
        m = collect_security_training_metrics(
            hrms_url=Config.HRMS_API_URL, hrms_key=Config.HRMS_API_KEY,
            hrms_username=Config.HRMS_API_USERNAME, hrms_password=Config.HRMS_API_PASSWORD)
        update_security_training_metrics(m)
        logger.info(f"[SCHED] Training: {m['personnel_trained']}/{m['total_personnel']} trained")
    except Exception as e:
        logger.error(f"[SCHED] Training job failed: {e}", exc_info=True)

def _collect_mfa_metrics_job():
    try:
        m = collect_mfa_metrics(
            rac_url=Config.RAC_API_URL, rac_key=Config.RAC_API_KEY,
            rac_username=Config.RAC_API_USERNAME, rac_password=Config.RAC_API_PASSWORD,
            audit_log_project=Config.RAC_AUDIT_LOG_PROJECT,
            include_iap=Config.RAC_INCLUDE_IDENTITY_AWARE_PROXY)
        update_mfa_metrics(m)
        logger.info(f"[SCHED] MFA: {m['remote_users_with_mfa']}/{m['total_remote_users']} with MFA")
    except Exception as e:
        logger.error(f"[SCHED] MFA job failed: {e}", exc_info=True)

def _collect_critical_assets_siem_metrics_job():
    try:
        projects = get_inventory().get("projects", [])
        if not projects: return
        m = collect_critical_assets_siem_metrics(
            projects=projects, siem_type=Config.SIEM_TYPE,
            siem_url=Config.SIEM_API_URL, siem_key=Config.SIEM_API_KEY,
            siem_username=Config.SIEM_API_USERNAME, siem_password=Config.SIEM_API_PASSWORD,
            critical_label_key=Config.CRITICAL_ASSET_LABEL_KEY,
            critical_label_value=Config.CRITICAL_ASSET_LABEL_VALUE)
        update_critical_assets_siem_metrics(m)
        logger.info(f"[SCHED] SIEM: {m['critical_assets_integrated']}/{m['total_critical_assets']} integrated")
    except Exception as e:
        logger.error(f"[SCHED] SIEM job failed: {e}", exc_info=True)


def get_scheduler():
    if _scheduler is None:
        raise RuntimeError("Scheduler not initialised")
    return _scheduler

def shutdown_scheduler():
    global _scheduler
    if _scheduler:
        _scheduler.shutdown()
        _scheduler = None
        logger.info("Scheduler shut down")

__all__ = ["init_scheduler", "get_scheduler", "shutdown_scheduler",
           "_collect_kms_metrics_job", "_collect_certificate_metrics_job",
           "_collect_secret_metrics_job", "_collect_vulnerability_metrics_job"]

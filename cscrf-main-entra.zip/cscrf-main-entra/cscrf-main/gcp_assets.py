"""
GCP Assets: Cloud KMS, Certificate Authority Service, Secret Manager.
Auth: Application Default Credentials (ADC) via Workload Identity on GCE VM,
      or `gcloud auth application-default login` locally.
"""
import logging
import threading
from datetime import datetime
from typing import Dict, List

import google.auth
import google.auth.transport.requests
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_state = {
    "kms":          {"last_collected": None, "total_keyrings": 0, "total_crypto_keys": 0,
                     "total_enabled_versions": 0, "total_disabled_versions": 0,
                     "total_destroyed_versions": 0, "keys": [], "by_project": {}},
    "certificates": {"last_collected": None, "total": 0, "active": 0, "expiring_soon": 0,
                     "expired": 0, "certs": [], "by_project": {}},
    "secrets":      {"last_collected": None, "total": 0, "active": 0, "disabled": 0,
                     "secrets": [], "by_project": {}},
}

_SCOPE = "https://www.googleapis.com/auth/cloud-platform"


def _creds():
    creds, proj = google.auth.default(scopes=[_SCOPE])
    creds.refresh(google.auth.transport.requests.Request())
    logger.info(f"ADC resolved (project: {proj})")
    return creds


def _client(svc, ver):
    return build(svc, ver, credentials=_creds(), cache_discovery=False)


# ─────────────────────────────────────────────────────────────────────────────
# Cloud KMS  — uses native google-cloud-kms library
# ─────────────────────────────────────────────────────────────────────────────

def collect_kms_metrics(projects: List[Dict]) -> Dict:
    try:
        from google.cloud import kms_v1
        from google.api_core.exceptions import GoogleAPICallError, PermissionDenied, NotFound
        from google.oauth2.credentials import Credentials as OAuthCreds

        # Build KMS client explicitly with ADC credentials
        creds, _ = google.auth.default(scopes=[_SCOPE])
        kms = kms_v1.KeyManagementServiceClient(credentials=creds)

        # Also build REST client for listing locations
        rest = _client("cloudkms", "v1")

        all_keys = []
        by_project: Dict[str, Dict] = {}
        total_kr = total_ck = total_en = total_dis = total_des = 0

        for project in projects:
            pid = project.get("project_id")
            if not pid:
                continue

            logger.info(f"[KMS] ── Project: {pid}")
            pd = {"keyrings": 0, "crypto_keys": 0, "enabled_versions": 0,
                  "disabled_versions": 0, "destroyed_versions": 0, "keys": []}

            # Step 1: get locations via REST (more reliable than SDK for listing)
            try:
                resp = rest.projects().locations().list(name=f"projects/{pid}").execute()
                locs = [l["locationId"] for l in resp.get("locations", [])]
                logger.info(f"[KMS] {pid}: {len(locs)} locations found")
            except Exception as e:
                logger.error(f"[KMS] Cannot list locations for {pid}: {e}")
                by_project[pid] = pd
                continue

            for loc in locs:
                parent = f"projects/{pid}/locations/{loc}"

                # Step 2: list keyrings
                try:
                    keyrings = list(kms.list_key_rings(request={"parent": parent}))
                except (PermissionDenied, NotFound):
                    continue
                except GoogleAPICallError as e:
                    logger.debug(f"[KMS] Skip {loc}: {e.message if hasattr(e,'message') else e}")
                    continue

                for kr in keyrings:
                    kr_short = kr.name.split("/")[-1]
                    pd["keyrings"] += 1
                    total_kr += 1
                    logger.info(f"[KMS] Keyring: {kr_short} @ {loc}")

                    # Step 3: list crypto keys
                    try:
                        ckeys = list(kms.list_crypto_keys(request={"parent": kr.name}))
                    except GoogleAPICallError as e:
                        logger.warning(f"[KMS] list_crypto_keys failed for {kr.name}: {e}")
                        continue

                    for ck in ckeys:
                        ck_short = ck.name.split("/")[-1]
                        purpose = kms_v1.CryptoKey.CryptoKeyPurpose(ck.purpose).name
                        next_rot = ck.next_rotation_time.isoformat() if ck.next_rotation_time else None
                        pd["crypto_keys"] += 1
                        total_ck += 1

                        # Step 4: count versions
                        en = dis = des = 0
                        try:
                            vers = list(kms.list_crypto_key_versions(request={"parent": ck.name}))
                            for v in vers:
                                sname = kms_v1.CryptoKeyVersion.CryptoKeyVersionState(v.state).name
                                if sname == "ENABLED":           en  += 1
                                elif sname == "DISABLED":        dis += 1
                                elif "DESTROY" in sname:         des += 1
                        except GoogleAPICallError:
                            pass

                        pd["enabled_versions"]   += en
                        pd["disabled_versions"]  += dis
                        pd["destroyed_versions"] += des
                        total_en  += en
                        total_dis += dis
                        total_des += des

                        row = {
                            "project": pid, "location": loc,
                            "keyring": kr_short, "key_name": ck_short,
                            "purpose": purpose,
                            "versions": en + dis + des,
                            "enabled_versions": en, "disabled_versions": dis,
                            "destroyed_versions": des,
                            "next_rotation": next_rot,
                        }
                        pd["keys"].append(row)
                        all_keys.append(row)
                        logger.info(f"[KMS]   Key: {ck_short} | {purpose} | en={en} dis={dis} des={des}")

            by_project[pid] = pd

        result = {
            "last_collected": datetime.utcnow(),
            "total_keyrings": total_kr, "total_crypto_keys": total_ck,
            "total_enabled_versions": total_en, "total_disabled_versions": total_dis,
            "total_destroyed_versions": total_des,
            "keys": all_keys, "by_project": by_project,
        }
        logger.info(f"[KMS] DONE ── {total_kr} keyrings | {total_ck} keys | "
                    f"en={total_en} dis={total_dis} des={total_des}")
        return result

    except ImportError:
        logger.error("[KMS] google-cloud-kms not installed! Run: pip install google-cloud-kms")
        return _empty_kms()
    except Exception as e:
        logger.error(f"[KMS] Fatal: {e}", exc_info=True)
        return _empty_kms()


def _empty_kms():
    return {"last_collected": None, "total_keyrings": 0, "total_crypto_keys": 0,
            "total_enabled_versions": 0, "total_disabled_versions": 0,
            "total_destroyed_versions": 0, "keys": [], "by_project": {}}


# ─────────────────────────────────────────────────────────────────────────────
# Certificate Authority Service
# ─────────────────────────────────────────────────────────────────────────────

def collect_certificate_metrics(projects: List[Dict]) -> Dict:
    try:
        ca = _client("privateca", "v1")
        all_certs, by_project = [], {}
        total = active = expiring = expired = 0
        now = datetime.utcnow()

        for project in projects:
            pid = project.get("project_id")
            if not pid:
                continue
            logger.info(f"[CERTS] Project: {pid}")
            pd = {"total": 0, "active": 0, "expiring_soon": 0, "expired": 0, "certs": []}

            try:
                locs = ca.projects().locations().list(name=f"projects/{pid}").execute().get("locations", [])
                for loc in locs:
                    lid = loc["locationId"]
                    parent = f"projects/{pid}/locations/{lid}"
                    try:
                        pools = ca.projects().locations().caPools().list(parent=parent).execute().get("caPools", [])
                    except HttpError:
                        continue
                    for pool in pools:
                        pname = pool["name"]
                        try:
                            certs = ca.projects().locations().caPools().certificates().list(parent=pname).execute().get("certificates", [])
                        except HttpError:
                            continue
                        for cert in certs:
                            cname  = cert["name"].split("/")[-1]
                            revoked = cert.get("revocationDetails") is not None
                            sdesc  = cert.get("subjectDescription", {})
                            subj   = sdesc.get("subjectAltName", {}).get("dnsNames", ["—"])[0]
                            nastr  = sdesc.get("notAfterTime")
                            dl = None; na = None
                            status = "REVOKED" if revoked else "ACTIVE"
                            if not revoked and nastr:
                                try:
                                    na = datetime.fromisoformat(nastr.replace("Z", "+00:00")).replace(tzinfo=None)
                                    dl = (na - now).days
                                    status = "EXPIRED" if dl < 0 else "EXPIRING_SOON" if dl < 30 else "ACTIVE"
                                except Exception:
                                    pass
                            row = {"project": pid, "location": lid, "ca_pool": pname.split("/")[-1],
                                   "name": cname, "subject": subj, "status": status,
                                   "not_after": na.isoformat() if na else "—", "days_left": dl}
                            total += 1; pd["total"] += 1
                            if status == "ACTIVE":         active += 1; pd["active"] += 1
                            elif status == "EXPIRING_SOON": active += 1; expiring += 1; pd["active"] += 1; pd["expiring_soon"] += 1
                            elif status == "EXPIRED":       expired += 1; pd["expired"] += 1
                            all_certs.append(row); pd["certs"].append(row)
            except Exception as e:
                logger.warning(f"[CERTS] {pid}: {e}")
            by_project[pid] = pd

        result = {"last_collected": datetime.utcnow(), "total": total, "active": active,
                  "expiring_soon": expiring, "expired": expired, "certs": all_certs, "by_project": by_project}
        logger.info(f"[CERTS] DONE ── {total} total | {active} active | {expiring} expiring | {expired} expired")
        return result
    except Exception as e:
        logger.error(f"[CERTS] Fatal: {e}", exc_info=True)
        return _empty_certs()


def _empty_certs():
    return {"last_collected": None, "total": 0, "active": 0, "expiring_soon": 0,
            "expired": 0, "certs": [], "by_project": {}}


# ─────────────────────────────────────────────────────────────────────────────
# Secret Manager
# ─────────────────────────────────────────────────────────────────────────────

def collect_secret_metrics(projects: List[Dict]) -> Dict:
    try:
        sm = _client("secretmanager", "v1")
        all_secrets, by_project = [], {}
        total = active = disabled = 0

        for project in projects:
            pid = project.get("project_id")
            if not pid:
                continue
            logger.info(f"[SECRETS] Project: {pid}")
            pd = {"total": 0, "active": 0, "disabled": 0, "secrets": []}
            try:
                secrets = sm.projects().secrets().list(parent=f"projects/{pid}").execute().get("secrets", [])
                for s in secrets:
                    sname = s["name"].split("/")[-1]
                    labels = s.get("labels", {})
                    ctime  = s.get("createTime", "—")
                    vcnt = 0; lvstate = "UNKNOWN"
                    try:
                        vers = sm.projects().secrets().versions().list(parent=s["name"]).execute().get("versions", [])
                        vcnt = len(vers)
                        if vers:
                            lvstate = vers[-1].get("state", "UNKNOWN")
                    except HttpError:
                        pass
                    is_dis = lvstate == "DISABLED"
                    row = {"project": pid, "name": sname, "version_count": vcnt,
                           "latest_version_state": lvstate, "create_time": ctime,
                           "labels": labels, "is_disabled": is_dis}
                    total += 1; pd["total"] += 1
                    if is_dis: disabled += 1; pd["disabled"] += 1
                    else:      active   += 1; pd["active"]   += 1
                    all_secrets.append(row); pd["secrets"].append(row)
            except Exception as e:
                logger.warning(f"[SECRETS] {pid}: {e}")
            by_project[pid] = pd

        result = {"last_collected": datetime.utcnow(), "total": total,
                  "active": active, "disabled": disabled,
                  "secrets": all_secrets, "by_project": by_project}
        logger.info(f"[SECRETS] DONE ── {total} total | {active} active | {disabled} disabled")
        return result
    except Exception as e:
        logger.error(f"[SECRETS] Fatal: {e}", exc_info=True)
        return _empty_secrets()


def _empty_secrets():
    return {"last_collected": None, "total": 0, "active": 0,
            "disabled": 0, "secrets": [], "by_project": {}}


# ─────────────────────────────────────────────────────────────────────────────
# Cached state accessors
# ─────────────────────────────────────────────────────────────────────────────

def get_kms_metrics() -> Dict:
    with _lock: return _state["kms"].copy()
def update_kms_metrics(m: Dict):
    with _lock: _state["kms"] = m

def get_certificate_metrics() -> Dict:
    with _lock: return _state["certificates"].copy()
def update_certificate_metrics(m: Dict):
    with _lock: _state["certificates"] = m

def get_secret_metrics() -> Dict:
    with _lock: return _state["secrets"].copy()
def update_secret_metrics(m: Dict):
    with _lock: _state["secrets"] = m

__all__ = [
    "collect_kms_metrics",         "get_kms_metrics",         "update_kms_metrics",
    "collect_certificate_metrics", "get_certificate_metrics", "update_certificate_metrics",
    "collect_secret_metrics",      "get_secret_metrics",      "update_secret_metrics",
]

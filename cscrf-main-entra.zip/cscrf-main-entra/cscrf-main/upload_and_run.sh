#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Run this from your LOCAL machine (Cloud Shell or laptop)
#  to upload the app to the VM and start it
# ─────────────────────────────────────────────────────────────

VM_NAME="kms-dashboard-vm"
ZONE="us-central1-a"
PROJECT="prefab-bounty-480110-d2"

echo "Uploading app to VM..."
gcloud compute scp cscrf-main.zip ${VM_NAME}:~/ \
    --zone=${ZONE} \
    --project=${PROJECT}

echo "Running setup on VM..."
gcloud compute ssh ${VM_NAME} \
    --zone=${ZONE} \
    --project=${PROJECT} \
    --command="
        set -e
        echo '--- Extracting app ---'
        mkdir -p ~/cscrf-dashboard
        unzip -o ~/cscrf-main.zip -d /tmp/cscrf_extract
        cp -r /tmp/cscrf_extract/cscrf-main/* ~/cscrf-dashboard/
        echo '--- Running setup ---'
        bash ~/cscrf-dashboard/setup.sh
    "

echo ""
echo "=========================================="
echo "  Dashboard: http://35.188.133.34:5000"
echo "  Username : admin"
echo "  Password : CscrfDemo@2026"
echo "=========================================="

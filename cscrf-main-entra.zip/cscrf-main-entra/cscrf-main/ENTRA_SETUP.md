# Microsoft Entra SSO Setup Guide

## Step 1 — Create App Registration in Azure Portal

1. Go to [portal.azure.com](https://portal.azure.com)
2. Search for **"Azure Active Directory"** (or "Microsoft Entra ID")
3. Click **"App Registrations"** → **"New Registration"**
4. Fill in:
   - **Name:** `CSCRF Dashboard`
   - **Supported account types:** `Accounts in this organizational directory only`
   - **Redirect URI:** `Web` → `http://35.188.133.34:5000/auth/callback`
5. Click **Register**

---

## Step 2 — Copy your credentials

From the **Overview** page, copy:
- **Application (client) ID** → this is your `ENTRA_CLIENT_ID`
- **Directory (tenant) ID**  → this is your `ENTRA_TENANT_ID`

---

## Step 3 — Create a Client Secret

1. In your App Registration → **"Certificates & Secrets"**
2. Click **"New client secret"**
3. Description: `cscrf-dashboard-secret`
4. Expiry: `24 months`
5. Click **Add**
6. **Copy the VALUE immediately** (you can't see it again)
   → this is your `ENTRA_CLIENT_SECRET`

---

## Step 4 — Add API permissions (for group membership)

Only needed if you want to restrict access by Azure AD group:

1. **"API Permissions"** → **"Add a permission"**
2. **Microsoft Graph** → **Delegated permissions**
3. Add: `GroupMember.Read.All`
4. Click **"Grant admin consent"**

---

## Step 5 — Update .env on the VM

SSH into your VM and edit the .env file:

```bash
gcloud compute ssh kms-dashboard-vm --zone=us-central1-a
nano ~/cscrf-dashboard/.env
```

Change these lines:
```
AUTH_MODE=entra
ENTRA_CLIENT_ID=your-client-id-here
ENTRA_CLIENT_SECRET=your-secret-value-here
ENTRA_TENANT_ID=your-tenant-id-here
OIDC_REDIRECT_URI=http://35.188.133.34:5000/auth/callback
```

Then restart the dashboard:
```bash
sudo systemctl restart cscrf-dashboard
```

---

## Step 6 — (Optional) Restrict to specific groups

To allow only specific Azure AD groups:

1. In Azure Portal → your App Registration → **"Token Configuration"**
2. **"Add groups claim"** → select **"Security groups"** → Save
3. Find your group's **Object ID** from Azure AD → Groups
4. Add to `.env`:
```
ENTRA_ALLOWED_GROUPS=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

Multiple groups (comma-separated):
```
ENTRA_ALLOWED_GROUPS=group-id-1,group-id-2
```

---

## Switching back to local auth

```
AUTH_MODE=local
```

Both modes can coexist — the login page shows both options when both are configured.

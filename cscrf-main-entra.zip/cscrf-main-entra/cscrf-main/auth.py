"""
Authentication module — supports two modes controlled by AUTH_MODE env var:

  AUTH_MODE=local   (default)
      Simple username/password login via DASHBOARD_USERNAME / DASHBOARD_PASSWORD.
      Use for local dev or when Entra is not yet configured.

  AUTH_MODE=entra
      Microsoft Entra ID (Azure AD) SSO via OpenID Connect.
      Requires: ENTRA_CLIENT_ID, ENTRA_CLIENT_SECRET, ENTRA_TENANT_ID,
                OIDC_REDIRECT_URI
      Optional: ENTRA_ALLOWED_GROUPS (comma-separated group IDs to restrict access)

Switch between modes by changing AUTH_MODE in your .env — zero code changes needed.
"""
import logging
from functools import wraps
from flask import (
    Blueprint, redirect, url_for, session,
    request, render_template_string, abort
)
from config import Config

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)

# ─────────────────────────────────────────────
# Shared helpers
# ─────────────────────────────────────────────

def init_auth(app):
    """Called from create_app(). Initialises whichever auth backend is active."""
    app.secret_key = Config.SECRET_KEY
    if Config.AUTH_MODE == "entra":
        _init_entra(app)
        logger.info("Auth mode: Microsoft Entra SSO (OIDC)")
    else:
        logger.info("Auth mode: Local username/password")


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("auth.login", next=request.url))
        return f(*args, **kwargs)
    return decorated


def get_current_user():
    return session.get("user")


# ─────────────────────────────────────────────
# Shared login page (used for local mode
# AND as the landing page for Entra SSO)
# ─────────────────────────────────────────────

_LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CSCRF Dashboard — Sign In</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: linear-gradient(135deg, #0d1b2e 0%, #1a3a5c 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      padding: 48px 40px 40px;
      width: 100%;
      max-width: 400px;
    }
    .logo { text-align: center; margin-bottom: 32px; }
    .logo h1 { font-size: 22px; color: #0d1b2e; font-weight: 700; }
    .logo p  { font-size: 13px; color: #6b7280; margin-top: 4px; }
    label {
      display: block; font-size: 13px; font-weight: 600;
      color: #374151; margin-bottom: 6px;
    }
    input[type=text], input[type=password] {
      width: 100%; padding: 10px 14px;
      border: 1.5px solid #d1d5db; border-radius: 7px;
      font-size: 14px; outline: none;
      transition: border-color .2s; margin-bottom: 18px;
    }
    input:focus { border-color: #2563eb; }
    .btn {
      width: 100%; padding: 11px; border: none; border-radius: 7px;
      font-size: 15px; font-weight: 600; cursor: pointer;
      transition: all .2s; display: flex; align-items: center;
      justify-content: center; gap: 10px; margin-bottom: 12px;
    }
    .btn-local  { background: #1e40af; color: #fff; }
    .btn-local:hover  { background: #1d4ed8; }
    .btn-entra  { background: #0078d4; color: #fff; }
    .btn-entra:hover  { background: #106ebe; }
    .divider {
      text-align: center; color: #9ca3af; font-size: 12px;
      margin: 16px 0; position: relative;
    }
    .divider::before, .divider::after {
      content: ""; position: absolute; top: 50%;
      width: 42%; height: 1px; background: #e5e7eb;
    }
    .divider::before { left: 0; }
    .divider::after  { right: 0; }
    .error {
      background: #fef2f2; border: 1px solid #fca5a5;
      color: #b91c1c; border-radius: 7px;
      padding: 10px 14px; font-size: 13px; margin-bottom: 18px;
    }
    .badge {
      display: block; margin-top: 20px; font-size: 11px;
      color: #9ca3af; text-align: center;
    }
    .ms-logo { font-size: 16px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">
      <h1>🔐 CSCRF Dashboard</h1>
      <p>Cloud Security &amp; Compliance Resource Framework</p>
    </div>

    {% if error %}
    <div class="error">{{ error }}</div>
    {% endif %}

    {% if entra_enabled %}
      <!-- Entra SSO button -->
      <a href="{{ url_for('auth.entra_login') }}" style="text-decoration:none;">
        <button class="btn btn-entra">
          <span class="ms-logo">⊞</span> Sign in with Microsoft
        </button>
      </a>

      {% if local_enabled %}
      <div class="divider">or</div>
      {% endif %}
    {% endif %}

    {% if local_enabled %}
      <!-- Local fallback login -->
      <form method="POST" action="{{ url_for('auth.login') }}">
        <input type="hidden" name="next" value="{{ next }}">
        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               placeholder="Enter username" autocomplete="username" required>
        <label for="password">Password</label>
        <input type="password" id="password" name="password"
               placeholder="Enter password" autocomplete="current-password" required>
        <button type="submit" class="btn btn-local">Sign in</button>
      </form>
    {% endif %}

    <span class="badge">Secured · GCP Workload Identity · {{ auth_mode_label }}</span>
  </div>
</body>
</html>
"""


def _render_login(error=None, next_url=""):
    entra_enabled = Config.AUTH_MODE == "entra"
    local_enabled = Config.AUTH_MODE == "local" or Config.DASHBOARD_PASSWORD
    auth_mode_label = "Microsoft Entra SSO" if entra_enabled else "Local Auth"
    return render_template_string(
        _LOGIN_HTML,
        error=error,
        next=next_url,
        entra_enabled=entra_enabled,
        local_enabled=local_enabled,
        auth_mode_label=auth_mode_label,
    )


# ─────────────────────────────────────────────
# LOCAL auth routes
# ─────────────────────────────────────────────

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    next_url = request.args.get("next") or request.form.get("next") or url_for("dashboard.dashboard")

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username == Config.DASHBOARD_USERNAME and password == Config.DASHBOARD_PASSWORD:
            session["user"] = {
                "name": username,
                "email": username,
                "auth_method": "local"
            }
            logger.info(f"Local login: {username}")
            return redirect(next_url)
        logger.warning(f"Failed local login attempt for: {username}")
        return _render_login(error="Invalid username or password.", next_url=next_url)

    return _render_login(next_url=next_url)


@auth_bp.route("/logout")
def logout():
    user = session.get("user", {})
    auth_method = user.get("auth_method", "local")
    session.clear()

    # If logged in via Entra, also sign out from Microsoft
    if auth_method == "entra":
        try:
            from config import Config as C
            end_session = (
                f"https://login.microsoftonline.com/{C.ENTRA_TENANT_ID}"
                f"/oauth2/v2.0/logout"
                f"?post_logout_redirect_uri={C.OIDC_REDIRECT_URI.replace('/auth/callback', '/auth/login')}"
            )
            return redirect(end_session)
        except Exception:
            pass

    return redirect(url_for("auth.login"))


# ─────────────────────────────────────────────
# ENTRA SSO routes
# ─────────────────────────────────────────────

_oauth = None


def _init_entra(app):
    global _oauth
    try:
        from authlib.integrations.flask_client import OAuth
        _oauth = OAuth(app)
        discovery_url = (
            f"https://login.microsoftonline.com/{Config.ENTRA_TENANT_ID}"
            f"/v2.0/.well-known/openid-configuration"
        )
        _oauth.register(
            name="entra",
            client_id=Config.ENTRA_CLIENT_ID,
            client_secret=Config.ENTRA_CLIENT_SECRET,
            server_metadata_url=discovery_url,
            client_kwargs={
                "scope": "openid profile email",
                # Request group membership claims if group restriction is enabled
                **({"claims": '{"id_token":{"groups":null}}'} if Config.ENTRA_ALLOWED_GROUPS else {})
            },
        )
        logger.info("Entra OIDC client registered successfully")
    except ImportError:
        logger.error("authlib not installed — run: pip install authlib")
        raise
    except Exception as e:
        logger.error(f"Failed to init Entra OIDC: {e}")
        raise


@auth_bp.route("/entra-login")
def entra_login():
    """Redirect user to Microsoft login page."""
    if _oauth is None:
        abort(500, "Entra SSO not configured")
    next_url = request.args.get("next", url_for("dashboard.dashboard"))
    session["login_next"] = next_url
    return _oauth.entra.authorize_redirect(redirect_uri=Config.OIDC_REDIRECT_URI)


@auth_bp.route("/callback")
def callback():
    """Handle Entra OIDC callback after successful Microsoft login."""
    if _oauth is None:
        abort(500, "Entra SSO not configured")

    try:
        token = _oauth.entra.authorize_access_token()
    except Exception as e:
        logger.error(f"Entra token exchange failed: {e}")
        return _render_login(error="Microsoft login failed. Please try again.")

    # Get user info
    userinfo = token.get("userinfo") or {}
    if not userinfo:
        try:
            resp = _oauth.entra.get("userinfo")
            userinfo = resp.json()
        except Exception:
            userinfo = {}

    user_id    = userinfo.get("oid") or userinfo.get("sub", "unknown")
    user_name  = userinfo.get("name") or userinfo.get("preferred_username", "Unknown")
    user_email = userinfo.get("email") or userinfo.get("upn") or userinfo.get("preferred_username", "")
    user_groups = userinfo.get("groups", [])

    # ── Group-based access control ──────────────────────────
    if Config.ENTRA_ALLOWED_GROUPS:
        allowed = set(Config.ENTRA_ALLOWED_GROUPS)
        user_group_set = set(user_groups)
        if not allowed.intersection(user_group_set):
            logger.warning(f"Access denied for {user_email} — not in allowed groups")
            return _render_login(
                error=f"Access denied. Your account ({user_email}) is not authorised to access this dashboard. "
                      f"Please contact your administrator."
            )

    session["user"] = {
        "id":          user_id,
        "name":        user_name,
        "email":       user_email,
        "groups":      user_groups,
        "auth_method": "entra",
    }
    logger.info(f"Entra SSO login: {user_email}")

    next_url = session.pop("login_next", url_for("dashboard.dashboard"))
    return redirect(next_url)


__all__ = ["init_auth", "auth_bp", "login_required", "get_current_user"]
